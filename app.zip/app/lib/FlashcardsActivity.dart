import 'package:flutter/material.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'config.dart';

// Category Model
class Category {
  final int categoryId;
  final String categoryName;
  final String description;
  final String colorCode;
  final String icon;

  Category({
    required this.categoryId,
    required this.categoryName,
    required this.description,
    required this.colorCode,
    required this.icon,
  });

  factory Category.fromJson(Map<String, dynamic> json) {
    return Category(
      categoryId: json['category_id'] is int ? json['category_id'] : int.tryParse(json['category_id'].toString()) ?? 0,
      categoryName: json['category_name'] ?? '',
      description: json['description'] ?? '',
      colorCode: json['color_code'] ?? '#3498db',
      icon: json['icon'] ?? '',
    );
  }

  Color getCategoryColor() {
    try {
      String hex = colorCode;
      if (hex.startsWith('#')) {
        hex = hex.replaceFirst('#', '0xff');
      } else {
        hex = '0xff$hex';
      }
      return Color(int.parse(hex));
    } catch (e) {
      return Colors.blue;
    }
  }
}

// Flashcard Model
class Flashcard {
  final int flashcardId;
  final String category;
  final String question;
  final String answer;
  final String? hint;
  final String status;
  final String difficulty;
  final int studyCount;
  final int timesCorrect;
  final String createdAt;

  Flashcard({
    required this.flashcardId,
    required this.category,
    required this.question,
    required this.answer,
    this.hint,
    required this.status,
    required this.difficulty,
    required this.studyCount,
    required this.timesCorrect,
    required this.createdAt,
  });

  factory Flashcard.fromJson(Map<String, dynamic> json) {
    return Flashcard(
      flashcardId: json['flashcard_id'] is int ? json['flashcard_id'] : int.tryParse(json['flashcard_id'].toString()) ?? 0,
      category: json['category'] ?? '',
      question: json['question'] ?? '',
      answer: json['answer'] ?? '',
      hint: json['hint'],
      status: json['status'] ?? 'new',
      difficulty: json['difficulty'] ?? 'medium',
      studyCount: json['study_count'] is int ? json['study_count'] : int.tryParse(json['study_count'].toString()) ?? 0,
      timesCorrect: json['times_correct'] is int ? json['times_correct'] : int.tryParse(json['times_correct'].toString()) ?? 0,
      createdAt: json['created_at'] ?? '',
    );
  }
}

class FlashcardsActivity extends StatefulWidget {
  final dynamic userId;
  const FlashcardsActivity({Key? key, this.userId}) : super(key: key);

  @override
  State<FlashcardsActivity> createState() => _FlashcardsActivityState();
}

class _FlashcardsActivityState extends State<FlashcardsActivity> {
  // State variables
  List<Category> categories = [];
  List<Flashcard> flashcards = [];
  String? selectedCategory;
  bool isLoading = false;
  bool isStudyMode = false;

  // Study mode variables
  int currentCardIndex = 0;
  bool isCardFlipped = false;
  int score = 0;
  int cardsLearned = 0;
  int cardsNotLearned = 0;
  late Timer _timer;
  int timeRemaining = 300;
  bool sessionEnded = false;

  @override
  void initState() {
    super.initState();
    _loadCategories();
  }

  @override
  void dispose() {
    if (_timer.isActive) {
      _timer.cancel();
    }
    super.dispose();
  }

  // Load categories from API
  Future<void> _loadCategories() async {
    setState(() => isLoading = true);
    try {
      final response = await http.get(
        Uri.parse('${Config.apiBaseUrl}get_categories.php'),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        if (json['success'] == true && json['data'] != null) {
          List<dynamic> data = json['data'];
          setState(() {
            categories = data.map((item) => Category.fromJson(item)).toList();
            isLoading = false;
          });
        } else {
          throw Exception(json['message'] ?? 'Failed to fetch categories');
        }
      } else {
        throw Exception('Server error: ${response.statusCode}');
      }
    } catch (e) {
      _showError('Failed to load categories: ${e.toString()}');
      setState(() => isLoading = false);
    }
  }

  // Generate flashcards for selected category
  Future<void> _generateFlashcards() async {
    if (selectedCategory == null) {
      _showError('Please select a category');
      return;
    }

    setState(() => isLoading = true);
    try {
      final Uri url = Uri.parse('${Config.apiBaseUrl}get_flashcards.php')
          .replace(queryParameters: {'category': selectedCategory});

      final response = await http.get(url).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        if (json['success'] == true && json['data'] != null) {
          List<dynamic> data = json['data'];
          List<Flashcard> loadedFlashcards = data.map((item) => Flashcard.fromJson(item)).toList();

          if (loadedFlashcards.isEmpty) {
            _showError('No flashcards found for this category');
            setState(() => isLoading = false);
            return;
          }

          setState(() {
            flashcards = loadedFlashcards;
            isStudyMode = true;
            currentCardIndex = 0;
            isCardFlipped = false;
            score = 0;
            cardsLearned = 0;
            cardsNotLearned = 0;
            timeRemaining = 300;
            sessionEnded = false;
            isLoading = false;
          });

          _startTimer();
        } else {
          throw Exception(json['message'] ?? 'Failed to fetch flashcards');
        }
      } else {
        throw Exception('Server error: ${response.statusCode}');
      }
    } catch (e) {
      _showError('Failed to load flashcards: ${e.toString()}');
      setState(() => isLoading = false);
    }
  }

  // Start study session timer
  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (timeRemaining > 0) {
          timeRemaining--;
        } else {
          _endSession('timeout');
        }
      });
    });
  }

  // Handle card flip
  void _flipCard() {
    setState(() {
      isCardFlipped = !isCardFlipped;
    });
  }

  // Handle learned button
  Future<void> _markLearned() async {
    try {
      final response = await http.post(
        Uri.parse('${Config.apiBaseUrl}update_flashcard_status.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'flashcard_id': flashcards[currentCardIndex].flashcardId,
          'status': 'learned',
          'is_correct': 1,
        }),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        setState(() {
          score++;
          cardsLearned++;
        });
        _nextCard();
      } else {
        throw Exception('Failed to update card');
      }
    } catch (e) {
      _showError('Failed to update card: ${e.toString()}');
    }
  }

  // Handle not learned button
  Future<void> _markNotLearned() async {
    try {
      final response = await http.post(
        Uri.parse('${Config.apiBaseUrl}update_flashcard_status.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'flashcard_id': flashcards[currentCardIndex].flashcardId,
          'status': 'learning',
          'is_correct': 0,
        }),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        setState(() {
          cardsNotLearned++;
        });
        _nextCard();
      } else {
        throw Exception('Failed to update card');
      }
    } catch (e) {
      _showError('Failed to update card: ${e.toString()}');
    }
  }

  // Move to next card
  void _nextCard() {
    setState(() {
      isCardFlipped = false;
      if (currentCardIndex < flashcards.length - 1) {
        currentCardIndex++;
      } else {
        _endSession('completed');
      }
    });
  }

  // End study session
  Future<void> _endSession(String status) async {
    if (_timer.isActive) {
      _timer.cancel();
    }

    setState(() => sessionEnded = true);

    try {
      final response = await http.post(
        Uri.parse('${Config.apiBaseUrl}save_session.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'category': selectedCategory,
          'total_cards': flashcards.length,
          'cards_learned': cardsLearned,
          'cards_not_learned': cardsNotLearned,
          'score': score,
          'time_spent': 300 - timeRemaining,
          'status': status,
        }),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode != 200) {
        debugPrint('Error saving session');
      }
    } catch (e) {
      debugPrint('Error saving session: ${e.toString()}');
    }

    _showSessionSummary(status);
  }

  // Restart same category
  void _restartSession() {
    Navigator.of(context).pop();
    setState(() {
      sessionEnded = false;
      isStudyMode = true;
      currentCardIndex = 0;
      isCardFlipped = false;
      score = 0;
      cardsLearned = 0;
      cardsNotLearned = 0;
      timeRemaining = 300;
    });
    _generateFlashcards();
  }

  // Choose another category
  void _chooseAnotherCategory() {
    setState(() {
      sessionEnded = false;
      isStudyMode = false;
      selectedCategory = null;
      currentCardIndex = 0;
      isCardFlipped = false;
      score = 0;
      cardsLearned = 0;
      cardsNotLearned = 0;
    });
  }

  // Show error dialog
  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // Show session summary
  void _showSessionSummary(String status) {
    int timeLeft = timeRemaining;
    bool isTimeUp = status == 'timeout';

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Row(
            children: [
              Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: isTimeUp ? Color(0xFFef4444).withOpacity(0.1) : Color(0xFF10b981).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  isTimeUp ? Icons.warning_rounded : Icons.check_circle,
                  color: isTimeUp ? Color(0xFFef4444) : Color(0xFF10b981),
                  size: 28,
                ),
              ),
              SizedBox(width: 12),
              Text(
                isTimeUp ? 'Time\'s Up!' : 'Great Job!',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF1a1a2e),
                ),
              ),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  isTimeUp
                      ? 'Try again to improve your score!'
                      : 'You finished in time!',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey[600],
                    fontWeight: FontWeight.w500,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Color(0xFFF3F4F6),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    children: [
                      _buildSummaryRow('Total Score:', '$score / ${flashcards.length}', Color(0xFF6366f1)),
                      const SizedBox(height: 12),
                      _buildSummaryRow('Learned:', cardsLearned.toString(), Color(0xFF10b981)),
                      const SizedBox(height: 12),
                      _buildSummaryRow('Not Learned:', cardsNotLearned.toString(), Color(0xFFef4444)),
                      const SizedBox(height: 12),
                      _buildSummaryRow('Time Left:', '${timeLeft ~/ 60}:${(timeLeft % 60).toString().padLeft(2, '0')}', Color(0xFFf59e0b)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton.icon(
              onPressed: _restartSession,
              icon: const Icon(Icons.refresh),
              label: const Text('Restart Same'),
              style: TextButton.styleFrom(
                foregroundColor: Color(0xFF6366f1),
              ),
            ),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.of(context).pop();
                _chooseAnotherCategory();
              },
              icon: const Icon(Icons.category),
              label: const Text('Choose Another'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF6366f1),
                foregroundColor: Colors.white,
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildSummaryRow(String label, String value, Color color) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 13,
            color: Colors.grey[600],
            fontWeight: FontWeight.w600,
          ),
        ),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            value,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w800,
              color: color,
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: isLoading
          ? Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF6366f1)),
        ),
      )
          : !isStudyMode
          ? _buildCategorySelectionView()
          : _buildStudyModeView(),
    );
  }

  // Category Selection View
  Widget _buildCategorySelectionView() {
    return RefreshIndicator(
      onRefresh: _loadCategories,
      color: Color(0xFF6366f1),
      child: SingleChildScrollView(
        physics: AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Select a Category',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w800,
                color: Color(0xFF1a1a2e),
                letterSpacing: 0.3,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Choose a category to start studying',
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey[600],
                fontWeight: FontWeight.w500,
              ),
            ),
            SizedBox(height: 24),
            GridView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.0,
              ),
              itemCount: categories.length,
              itemBuilder: (context, index) {
                final category = categories[index];
                final isSelected = selectedCategory == category.categoryName;
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      selectedCategory = isSelected ? null : category.categoryName;
                    });
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: isSelected
                              ? Color(0xFF6366f1).withOpacity(0.3)
                              : Colors.black.withOpacity(0.05),
                          blurRadius: isSelected ? 16 : 8,
                          offset: Offset(0, isSelected ? 4 : 2),
                        ),
                      ],
                      border: Border.all(
                        color: isSelected ? Color(0xFF6366f1) : Colors.transparent,
                        width: 2,
                      ),
                    ),
                    padding: EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Color(0xFF6366f1).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            Icons.school_outlined,
                            size: 24,
                            color: Color(0xFF6366f1),
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              category.categoryName,
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                                color: Color(0xFF1a1a2e),
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            SizedBox(height: 4),
                            Text(
                              category.description,
                              style: TextStyle(
                                fontSize: 11,
                                color: Colors.grey[500],
                                fontWeight: FontWeight.w500,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                        if (isSelected)
                          Icon(Icons.check_circle, color: Color(0xFF6366f1), size: 20),
                      ],
                    ),
                  ),
                );
              },
            ),
            SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton.icon(
                onPressed: selectedCategory != null ? _generateFlashcards : null,
                icon: Icon(Icons.play_arrow, size: 22),
                label: Text(
                  'Start Study Session',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.3,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF6366f1),
                  disabledBackgroundColor: Colors.grey[300],
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  elevation: 8,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Study Mode View
  Widget _buildStudyModeView() {
    if (sessionEnded) {
      return const SizedBox.shrink();
    }

    final card = flashcards[currentCardIndex];
    final progressPercent = ((currentCardIndex + 1) / flashcards.length * 100).toInt();

    return Column(
      children: [
        // Header with timer and progress
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF6366f1), Color(0xFF8b5cf6)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: Color(0xFF6366f1).withOpacity(0.2),
                blurRadius: 12,
                offset: Offset(0, 4),
              ),
            ],
          ),
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          selectedCategory ?? 'Flashcards',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.9),
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                            letterSpacing: 0.2,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Progress: ${currentCardIndex + 1} / ${flashcards.length}',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                            letterSpacing: 0.2,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.3),
                        width: 1.5,
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.timer, color: Colors.white, size: 18),
                        SizedBox(width: 6),
                        Text(
                          '${(timeRemaining ~/ 60).toString().padLeft(2, '0')}:${(timeRemaining % 60).toString().padLeft(2, '0')}',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(height: 16),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: progressPercent / 100,
                  minHeight: 8,
                  backgroundColor: Colors.white.withOpacity(0.2),
                  valueColor: AlwaysStoppedAnimation<Color>(
                    progressPercent < 50
                        ? Color(0xFFef4444)
                        : progressPercent < 80
                        ? Color(0xFFf59e0b)
                        : Color(0xFF10b981),
                  ),
                ),
              ),
              SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Score: $score ⭐',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    'Learned: $cardsLearned',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        // Flashcard
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Center(
              child: GestureDetector(
                onTap: _flipCard,
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 300),
                  child: FlashcardWidget(
                    key: ValueKey(isCardFlipped),
                    card: card,
                    isFlipped: isCardFlipped,
                    hint: card.hint,
                  ),
                ),
              ),
            ),
          ),
        ),
        // Hint button
        if (!isCardFlipped && card.hint != null)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Color(0xFFFEF3C7),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Color(0xFFF59E0B),
                  width: 1.5,
                ),
              ),
              child: Row(
                children: [
                  Icon(Icons.lightbulb, color: Color(0xFFF59E0B), size: 20),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Hint',
                          style: TextStyle(
                            fontSize: 11,
                            color: Colors.orange[700],
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.2,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          card.hint ?? '',
                          style: TextStyle(
                            fontSize: 13,
                            fontStyle: FontStyle.italic,
                            color: Colors.orange[800],
                            fontWeight: FontWeight.w500,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        const SizedBox(height: 20),
        // Action buttons
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
          child: Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _markNotLearned,
                  icon: Icon(Icons.close, size: 20),
                  label: Text(
                    'Not Learned',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFFef4444),
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 4,
                  ),
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _markLearned,
                  icon: Icon(Icons.check, size: 20),
                  label: Text(
                    'Learned',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF10b981),
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 4,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// Flashcard Widget
class FlashcardWidget extends StatelessWidget {
  final Flashcard card;
  final bool isFlipped;
  final String? hint;

  const FlashcardWidget({
    Key? key,
    required this.card,
    required this.isFlipped,
    this.hint,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: isFlipped
              ? [Color(0xFF10b981), Color(0xFF059669)]
              : [Color(0xFF6366f1), Color(0xFF8b5cf6)],
        ),
        boxShadow: [
          BoxShadow(
            color: isFlipped
                ? Color(0xFF10b981).withOpacity(0.3)
                : Color(0xFF6366f1).withOpacity(0.3),
            blurRadius: 24,
            offset: Offset(0, 12),
          ),
        ],
      ),
      padding: EdgeInsets.all(32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: Colors.white.withOpacity(0.3),
                width: 1,
              ),
            ),
            child: Text(
              isFlipped ? 'ANSWER' : 'QUESTION',
              style: TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.5,
              ),
            ),
          ),
          SizedBox(height: 24),
          Expanded(
            child: SingleChildScrollView(
              child: Text(
                isFlipped ? card.answer : card.question,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  height: 1.6,
                  letterSpacing: 0.3,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
          SizedBox(height: 24),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.touch_app, color: Colors.white, size: 16),
                SizedBox(width: 6),
                Text(
                  'Tap to flip',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.8),
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}