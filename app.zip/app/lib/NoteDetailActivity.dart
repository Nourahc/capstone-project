import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'config.dart';
import 'SummaryActivity.dart';

class NoteDetailActivity extends StatefulWidget {
  final int userId;
  final Map<String, dynamic>? note;
  final bool showSummary;

  NoteDetailActivity({
    required this.userId,
    this.note,
    this.showSummary = false,
  });

  @override
  _NoteDetailActivityState createState() => _NoteDetailActivityState();
}

class _NoteDetailActivityState extends State<NoteDetailActivity> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _contentController = TextEditingController();
  bool _isLoading = false;
  bool _isEditMode = false;

  @override
  void initState() {
    super.initState();
    _isEditMode = widget.note != null;
    if (_isEditMode) {
      _titleController.text = widget.note!['title'];
      _contentController.text = widget.note!['content'];
    }

    // Auto-navigate to summary if requested
    if (widget.showSummary && _isEditMode) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _showSummaryScreen();
      });
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  Future<void> _saveNote() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final url = _isEditMode
          ? '${Config.apiBaseUrl}update_note.php'
          : '${Config.apiBaseUrl}add_note.php';

      final body = {
        'user_id': widget.userId,
        'title': _titleController.text.trim(),
        'content': _contentController.text.trim(),
      };

      if (_isEditMode) {
        body['note_id'] = widget.note!['note_id'];
      }

      final response = await http.post(
        Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(body),
      ).timeout(Duration(seconds: 10));

      final data = json.decode(response.body);

      if (data['success']) {
        _showSuccess(data['message'] ?? 'Note saved successfully');
        await Future.delayed(Duration(milliseconds: 500));
        Navigator.pop(context, true);
      } else {
        _showError(data['message'] ?? 'Failed to save note');
      }
    } catch (e) {
      print('Error: $e');
      _showError('Connection error. Please check your internet and try again.');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _showSummaryScreen() {
    if (!_isEditMode) {
      _showError('Please save the note first before generating summary');
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SummaryActivity(
          noteId: int.parse(widget.note!['note_id'].toString()),
          noteTitle: widget.note!['title'],
          noteContent: widget.note!['content'],
        ),
      ),
    ).then((result) {
      // If back button was pressed in SummaryActivity, pop to NotesActivity
      if (result == true) {
        Navigator.pop(context, true);
      }
    });
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        duration: Duration(seconds: 3),
      ),
    );
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green,
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF6366f1),
        elevation: 0,
        title: Text(
          _isEditMode ? 'Edit Note' : 'New Note',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: Colors.white,
            letterSpacing: 0.3,
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          if (!_isLoading)
            IconButton(
              icon: Icon(Icons.save, color: Colors.white),
              onPressed: _saveNote,
            ),
          if (_isEditMode) ...[
            IconButton(
              icon: Icon(Icons.summarize, color: Colors.white),
              onPressed: _showSummaryScreen,
              tooltip: 'Generate Summary',
            ),
          ],
        ],
      ),
      body: _isLoading
          ? Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF6366f1)),
        ),
      )
          : SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Title Field
              TextFormField(
                controller: _titleController,
                decoration: InputDecoration(
                  labelText: 'Title',
                  labelStyle: TextStyle(
                    color: Color(0xFF9ca3af),
                    fontSize: 14,
                  ),
                  hintText: 'Enter note title',
                  hintStyle: TextStyle(color: Colors.grey[400]),
                  prefixIcon: Icon(Icons.title_outlined, color: Color(0xFF6366f1)),
                  filled: true,
                  fillColor: Color(0xFFF3F4F6),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide(color: Color(0xFF6366f1), width: 2),
                  ),
                  contentPadding: EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                  errorStyle: TextStyle(fontSize: 12),
                ),
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a title';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),

              // Content Field
              TextFormField(
                controller: _contentController,
                decoration: InputDecoration(
                  labelText: 'Content',
                  labelStyle: TextStyle(
                    color: Color(0xFF9ca3af),
                    fontSize: 14,
                  ),
                  hintText: 'Enter your notes here...',
                  hintStyle: TextStyle(color: Colors.grey[400]),
                  alignLabelWithHint: true,
                  filled: true,
                  fillColor: Color(0xFFF3F4F6),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide(color: Color(0xFF6366f1), width: 2),
                  ),
                  contentPadding: EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                  errorStyle: TextStyle(fontSize: 12),
                ),
                maxLines: 15,
                style: TextStyle(
                  fontSize: 14,
                  height: 1.6,
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter some content';
                  }
                  return null;
                },
              ),
              SizedBox(height: 24),

              // Save Button
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF6366f1), Color(0xFF8b5cf6)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0xFF6366f1).withOpacity(0.3),
                      blurRadius: 12,
                      offset: Offset(0, 6),
                    ),
                  ],
                ),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: _isLoading ? null : _saveNote,
                    borderRadius: BorderRadius.circular(14),
                    child: Padding(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.save, color: Colors.white),
                          SizedBox(width: 8),
                          Text(
                            _isEditMode ? 'Update Note' : 'Create Note',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              // AI Features Section (only show for saved notes)
              if (_isEditMode) ...[
                SizedBox(height: 32),
                Divider(color: Colors.grey[300]),
                SizedBox(height: 24),
                Text(
                  'AI-Powered Features',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF8b5cf6),
                    letterSpacing: 0.3,
                  ),
                ),
                SizedBox(height: 16),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Color(0xFF8b5cf6).withOpacity(0.1),
                        Color(0xFF6366f1).withOpacity(0.05),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: Color(0xFF8b5cf6).withOpacity(0.2),
                      width: 1.5,
                    ),
                  ),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: _showSummaryScreen,
                      borderRadius: BorderRadius.circular(14),
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 16),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.summarize,
                              color: Color(0xFF8b5cf6),
                              size: 22,
                            ),
                            SizedBox(width: 8),
                            Text(
                              'Generate Summary',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                color: Color(0xFF8b5cf6),
                                letterSpacing: 0.3,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],

              // Timestamps
              if (_isEditMode) ...[
                SizedBox(height: 24),
                Container(
                  padding: EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.grey[100],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Created: ${widget.note!['created_at']}',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey[600],
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 6),
                      Text(
                        'Last Updated: ${widget.note!['updated_at']}',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey[600],
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}