import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'config.dart';
import 'NoteDetailActivity.dart';

class NotesActivity extends StatefulWidget {
  final int userId;

  NotesActivity({required this.userId});

  @override
  _NotesActivityState createState() => _NotesActivityState();
}

class _NotesActivityState extends State<NotesActivity> {
  List<dynamic> _notes = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchNotes();
  }
  Future<void> _fetchNotes() async {
    setState(() => _isLoading = true);

    final url = '${Config.apiBaseUrl}get_notes.php?user_id=${widget.userId}';
    print('Fetching URL: $url');

    try {
      final response = await http
          .get(Uri.parse(url))
          .timeout(const Duration(seconds: 10));

      print('Response status: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['success'] == true) {
          setState(() {
            _notes = data['notes'];
            _isLoading = false;
          });
        } else {
          _showError(data['message'] ?? 'Failed to load notes');
          setState(() => _isLoading = false);
        }
      } else {
        _showError('Server returned status code ${response.statusCode}');
        setState(() => _isLoading = false);
      }
    } catch (e) {
      print('Error fetching notes: $e');
      _showError('Connection error. Please check your internet and try again.');
      setState(() => _isLoading = false);
    }
  }

  Future<void> _deleteNote(int noteId) async {
    final url = '${Config.apiBaseUrl}delete_note.php';
    print('Deleting note URL: $url, noteId: $noteId');

    try {
      final response = await http
          .post(Uri.parse(url),
          headers: {'Content-Type': 'application/json'},
          body: json.encode({
            'note_id': noteId,
            'user_id': widget.userId,
          }))
          .timeout(const Duration(seconds: 10));

      print('Delete response status: ${response.statusCode}');
      print('Delete response body: ${response.body}');

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['success'] == true) {
          _showSuccess('Note deleted successfully');
          await _fetchNotes(); // Refresh notes after deletion
        } else {
          _showError(data['message'] ?? 'Failed to delete note');
        }
      } else {
        _showError('Server returned status code ${response.statusCode}');
      }
    } catch (e) {
      print('Error deleting note: $e');
      _showError('Connection error. Please try again.');
    }
  }

  void _confirmDelete(int noteId, String title) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          'Delete Note',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
        content: Text('Are you sure you want to delete "$title"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _deleteNote(noteId);
            },
            child: Text('Delete', style: TextStyle(color: Colors.red, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        duration: Duration(seconds: 3),
      ),
    );
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green,
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF9FAFB),
      body: _isLoading
          ? Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF6366f1)),
        ),
      )
          : _notes.isEmpty
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                color: Color(0xFF6366f1).withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Icon(
                Icons.note_outlined,
                size: 50,
                color: Color(0xFF6366f1),
              ),
            ),
            SizedBox(height: 24),
            Text(
              'No notes yet',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: Color(0xFF1a1a2e),
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Tap + to create your first note',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      )
          : RefreshIndicator(
        onRefresh: _fetchNotes,
        color: Color(0xFF6366f1),
        child: ListView.builder(
          padding: EdgeInsets.all(16.0),
          itemCount: _notes.length,
          itemBuilder: (context, index) {
            final note = _notes[index];
            return Container(
              margin: EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 12,
                    offset: Offset(0, 4),
                  ),
                ],
                border: Border.all(
                  color: Color(0xFF6366f1).withOpacity(0.1),
                  width: 1,
                ),
              ),
              child: Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Title and Delete Button
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: Color(0xFF6366f1).withOpacity(0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            Icons.note_outlined,
                            color: Color(0xFF6366f1),
                            size: 22,
                          ),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                note['title'],
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 16,
                                  color: Color(0xFF1a1a2e),
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              SizedBox(height: 4),
                              Text(
                                'Updated: ${note['updated_at']}',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: Colors.grey[500],
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                        IconButton(
                          icon: Icon(Icons.delete_outline, color: Colors.red),
                          onPressed: () => _confirmDelete(
                            int.parse(note['note_id'].toString()),
                            note['title'],
                          ),
                          visualDensity: VisualDensity.compact,
                        ),
                      ],
                    ),
                    SizedBox(height: 12),
                    // Content Preview
                    Text(
                      note['content'],
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey[700],
                        height: 1.5,
                      ),
                    ),
                    SizedBox(height: 16),
                    // Action Buttons
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () async {
                              final result = await Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => NoteDetailActivity(
                                    userId: widget.userId,
                                    note: note,
                                  ),
                                ),
                              );
                              if (result == true) {
                                _fetchNotes();
                              }
                            },
                            icon: Icon(Icons.edit_outlined, size: 18),
                            label: Text('Edit'),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Color(0xFF6366f1),
                              side: BorderSide(color: Color(0xFF6366f1)),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(width: 10),
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => NoteDetailActivity(
                                    userId: widget.userId,
                                    note: note,
                                    showSummary: true,
                                  ),
                                ),
                              );
                            },
                            icon: Icon(Icons.summarize, size: 18),
                            label: Text('Summary'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Color(0xFF8b5cf6),
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => NoteDetailActivity(
                userId: widget.userId,
              ),
            ),
          );
          if (result == true) {
            _fetchNotes();
          }
        },
        backgroundColor: Color(0xFF6366f1),
        foregroundColor: Colors.white,
        elevation: 8,
        child: Icon(Icons.add, size: 28),
      ),
    );
  }
}