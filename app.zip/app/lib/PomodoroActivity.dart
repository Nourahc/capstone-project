import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'config.dart';

// Singleton service to manage Pomodoro timer globally
class PomodoroService {
  static final PomodoroService _instance = PomodoroService._internal();

  factory PomodoroService() {
    return _instance;
  }

  PomodoroService._internal();

  Timer? _timer;
  int _remainingSeconds = 0;
  bool _isRunning = false;
  int _selectedDuration = 25;
  int? _userId;
  int? _sessionStartTime; // Unix timestamp when session started

  // Stream to notify listeners of timer changes
  final _timerController = StreamController<TimerUpdate>.broadcast();
  Stream<TimerUpdate> get timerStream => _timerController.stream;

  bool get isRunning => _isRunning;
  int get remainingSeconds => _remainingSeconds;
  int get selectedDuration => _selectedDuration;

  void initialize(int userId) {
    _userId = userId;
  }

  void startTimer(int durationMinutes) {
    if (_isRunning) return;

    _selectedDuration = durationMinutes;
    _remainingSeconds = durationMinutes * 60;
    _sessionStartTime = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    _isRunning = true;

    _timerController.add(TimerUpdate(
      remainingSeconds: _remainingSeconds,
      isRunning: _isRunning,
      selectedDuration: _selectedDuration,
    ));

    _timer?.cancel();
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (_remainingSeconds > 0) {
        _remainingSeconds--;

        _timerController.add(TimerUpdate(
          remainingSeconds: _remainingSeconds,
          isRunning: _isRunning,
          selectedDuration: _selectedDuration,
        ));
      }

      if (_remainingSeconds <= 0) {
        _completeSession();
      }
    });
  }

  void pauseTimer() {
    _timer?.cancel();
    _isRunning = false;
    _timerController.add(TimerUpdate(
      remainingSeconds: _remainingSeconds,
      isRunning: _isRunning,
      selectedDuration: _selectedDuration,
    ));
  }

  void resumeTimer() {
    if (_isRunning || _remainingSeconds <= 0) return;

    _isRunning = true;
    _timerController.add(TimerUpdate(
      remainingSeconds: _remainingSeconds,
      isRunning: _isRunning,
      selectedDuration: _selectedDuration,
    ));

    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      _remainingSeconds--;

      _timerController.add(TimerUpdate(
        remainingSeconds: _remainingSeconds,
        isRunning: _isRunning,
        selectedDuration: _selectedDuration,
      ));

      if (_remainingSeconds <= 0) {
        _completeSession();
      }
    });
  }

  void resetTimer() {
    _timer?.cancel();
    _isRunning = false;
    _remainingSeconds = _selectedDuration * 60;
    _sessionStartTime = null;
    // Don't save when resetting/stopping
    _timerController.add(TimerUpdate(
      remainingSeconds: _remainingSeconds,
      isRunning: _isRunning,
      selectedDuration: _selectedDuration,
    ));
  }

  Future<void> _completeSession() async {
    _timer?.cancel();
    _isRunning = false;

    if (_userId != null) {
      await _saveSession(_selectedDuration);
    }

    _timerController.add(TimerUpdate(
      remainingSeconds: 0,
      isRunning: false,
      selectedDuration: _selectedDuration,
      isCompleted: true,
    ));

    // Reset after a short delay
    await Future.delayed(Duration(milliseconds: 500));
    resetTimer();
  }

  Future<void> _saveSession(int duration) async {
    try {
      await http.post(
        Uri.parse('${Config.apiBaseUrl}/add_pomodoro.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'user_id': _userId,
          'duration_minutes': duration,
        }),
      );
    } catch (e) {
      print('Error saving session: $e');
    }
  }

  void dispose() {
    _timer?.cancel();
    _timerController.close();
  }
}

class TimerUpdate {
  final int remainingSeconds;
  final bool isRunning;
  final int selectedDuration;
  final bool isCompleted;

  TimerUpdate({
    required this.remainingSeconds,
    required this.isRunning,
    required this.selectedDuration,
    this.isCompleted = false,
  });
}

class PomodoroActivity extends StatefulWidget {
  final int userId;

  PomodoroActivity({required this.userId});

  @override
  _PomodoroActivityState createState() => _PomodoroActivityState();
}

class _PomodoroActivityState extends State<PomodoroActivity> {
  late PomodoroService _pomodoroService;
  List<dynamic> _sessions = [];
  int _totalMinutes = 0;
  int _totalSessions = 0;

  final List<int> _durations = [15, 25, 30, 45, 50];

  @override
  void initState() {
    super.initState();
    _pomodoroService = PomodoroService();
    _pomodoroService.initialize(widget.userId);
    _fetchSessions();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<void> _fetchSessions() async {
    try {
      final response = await http.get(
        Uri.parse('${Config.apiBaseUrl}/get_pomodoro.php?user_id=${widget.userId}'),
      );

      final data = json.decode(response.body);

      if (data['success']) {
        setState(() {
          _sessions = data['sessions'];
          _totalMinutes = data['total_minutes'];
          _totalSessions = data['total_sessions'];
        });
      }
    } catch (e) {
      print('Error fetching sessions: $e');
    }
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  void _showCompletionDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: Row(
          children: [
            Container(
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.green.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(Icons.check_circle, color: Colors.green, size: 28),
            ),
            SizedBox(width: 12),
            Text(
              'Session Complete!',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: Color(0xFF1a1a2e),
              ),
            ),
          ],
        ),
        content: Text(
          'Great job! You completed a ${_pomodoroService.selectedDuration} minute study session.',
          style: TextStyle(
            color: Colors.grey[600],
            fontSize: 14,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _fetchSessions();
            },
            style: TextButton.styleFrom(
              padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
            child: Text(
              'OK',
              style: TextStyle(
                color: Color(0xFF6366f1),
                fontWeight: FontWeight.w700,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _formatTime(int seconds) {
    int minutes = seconds ~/ 60;
    int remainingSeconds = seconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: _fetchSessions,
        color: Color(0xFF6366f1),
        child: SingleChildScrollView(
          physics: AlwaysScrollableScrollPhysics(),
          child: Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Timer Section
                StreamBuilder<TimerUpdate>(
                  stream: _pomodoroService.timerStream,
                  builder: (context, snapshot) {
                    final timerUpdate = snapshot.data;
                    final isRunning = timerUpdate?.isRunning ?? false;
                    final remainingSeconds = timerUpdate?.remainingSeconds ?? _pomodoroService.selectedDuration * 60;
                    final isCompleted = timerUpdate?.isCompleted ?? false;

                    if (isCompleted && snapshot.hasData) {
                      WidgetsBinding.instance.addPostFrameCallback((_) {
                        _showCompletionDialog();
                      });
                    }

                    return Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            isRunning
                                ? Color(0xFFf59e0b)
                                : Color(0xFF6366f1),
                            isRunning
                                ? Color(0xFFf97316)
                                : Color(0xFF8b5cf6),
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(24),
                        boxShadow: [
                          BoxShadow(
                            color: (isRunning
                                ? Color(0xFFf59e0b)
                                : Color(0xFF6366f1))
                                .withOpacity(0.3),
                            blurRadius: 20,
                            offset: Offset(0, 8),
                          ),
                        ],
                      ),
                      padding: EdgeInsets.all(28.0),
                      child: Column(
                        children: [
                          Text(
                            'Focus Time',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Colors.white.withOpacity(0.9),
                              letterSpacing: 0.3,
                            ),
                          ),
                          SizedBox(height: 24),
                          Container(
                            width: 200,
                            height: 200,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white.withOpacity(0.2),
                              border: Border.all(
                                color: Colors.white.withOpacity(0.4),
                                width: 4,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.1),
                                  blurRadius: 20,
                                  offset: Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Center(
                              child: Text(
                                _formatTime(remainingSeconds),
                                style: TextStyle(
                                  fontSize: 56,
                                  fontWeight: FontWeight.w800,
                                  color: Colors.white,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: 32),

                          // Duration Selector
                          if (!isRunning) ...[
                            Text(
                              'Select Duration',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: Colors.white.withOpacity(0.9),
                              ),
                            ),
                            SizedBox(height: 12),
                            Wrap(
                              spacing: 10,
                              runSpacing: 10,
                              children: _durations.map((duration) {
                                return ChoiceChip(
                                  label: Text(
                                    '$duration min',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      color: _pomodoroService.selectedDuration == duration
                                          ? Colors.black
                                          : Colors.grey[700],
                                    ),
                                  ),
                                  selected: _pomodoroService.selectedDuration == duration,
                                  backgroundColor: Colors.white.withOpacity(0.2),
                                  selectedColor: Colors.white.withOpacity(0.4),
                                  side: BorderSide(
                                    color: Colors.white.withOpacity(0.3),
                                    width: 1.5,
                                  ),
                                  onSelected: (selected) {
                                    if (!isRunning) {
                                      _pomodoroService._selectedDuration = duration;
                                      _pomodoroService._remainingSeconds = duration * 60;
                                      _pomodoroService._timerController.add(TimerUpdate(
                                        remainingSeconds: duration * 60,
                                        isRunning: false,
                                        selectedDuration: duration,
                                      ));
                                    }
                                  },
                                );
                              }).toList(),
                            ),
                            SizedBox(height: 28),
                          ],

                          // Control Buttons
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              if (!isRunning) ...[
                                Container(
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(14),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.15),
                                        blurRadius: 12,
                                        offset: Offset(0, 4),
                                      ),
                                    ],
                                  ),
                                  child: Material(
                                    color: Colors.transparent,
                                    child: InkWell(
                                      onTap: () => _pomodoroService.startTimer(_pomodoroService.selectedDuration),
                                      borderRadius: BorderRadius.circular(14),
                                      child: Padding(
                                        padding: EdgeInsets.symmetric(
                                          horizontal: 32,
                                          vertical: 14,
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Icon(
                                              Icons.play_arrow,
                                              size: 26,
                                              color: Color(0xFF10b981),
                                            ),
                                            SizedBox(width: 8),
                                            Text(
                                              'Start',
                                              style: TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.w700,
                                                color: Color(0xFF10b981),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ] else ...[
                                Container(
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(14),
                                    border: Border.all(
                                      color: Colors.white.withOpacity(0.3),
                                      width: 1.5,
                                    ),
                                  ),
                                  child: Material(
                                    color: Colors.transparent,
                                    child: InkWell(
                                      onTap: () => _pomodoroService.pauseTimer(),
                                      borderRadius: BorderRadius.circular(14),
                                      child: Padding(
                                        padding: EdgeInsets.symmetric(
                                          horizontal: 28,
                                          vertical: 12,
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Icon(
                                              Icons.pause,
                                              size: 24,
                                              color: Colors.white,
                                            ),
                                            SizedBox(width: 8),
                                            Text(
                                              'Pause',
                                              style: TextStyle(
                                                fontSize: 14,
                                                fontWeight: FontWeight.w700,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(width: 12),
                                Container(
                                  decoration: BoxDecoration(
                                    color: Colors.red.withOpacity(0.3),
                                    borderRadius: BorderRadius.circular(14),
                                    border: Border.all(
                                      color: Colors.white.withOpacity(0.3),
                                      width: 1.5,
                                    ),
                                  ),
                                  child: Material(
                                    color: Colors.transparent,
                                    child: InkWell(
                                      onTap: () => _pomodoroService.resetTimer(),
                                      borderRadius: BorderRadius.circular(14),
                                      child: Padding(
                                        padding: EdgeInsets.symmetric(
                                          horizontal: 28,
                                          vertical: 12,
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Icon(
                                              Icons.stop,
                                              size: 24,
                                              color: Colors.white,
                                            ),
                                            SizedBox(width: 8),
                                            Text(
                                              'Stop',
                                              style: TextStyle(
                                                fontSize: 14,
                                                fontWeight: FontWeight.w700,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                ),

                SizedBox(height: 28),

                // Statistics Section
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Your Statistics',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF1a1a2e),
                        letterSpacing: 0.2,
                      ),
                    ),
                    SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: _buildStatCard(
                            'Total Minutes',
                            _totalMinutes.toString(),
                            Icons.timer,
                            Color(0xFF6366f1),
                          ),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: _buildStatCard(
                            'Sessions',
                            _totalSessions.toString(),
                            Icons.check_circle,
                            Color(0xFF10b981),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),

                SizedBox(height: 24),

                // Recent Sessions
                if (_sessions.isNotEmpty) ...[
                  Text(
                    'Recent Sessions',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF1a1a2e),
                      letterSpacing: 0.2,
                    ),
                  ),
                  SizedBox(height: 12),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: _sessions.length > 5 ? 5 : _sessions.length,
                    itemBuilder: (context, index) {
                      final session = _sessions[index];
                      return Container(
                        margin: EdgeInsets.only(bottom: 8),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 8,
                              offset: Offset(0, 2),
                            ),
                          ],
                          border: Border.all(
                            color: Colors.grey.withOpacity(0.1),
                            width: 1,
                          ),
                        ),
                        child: Padding(
                          padding: EdgeInsets.all(12),
                          child: Row(
                            children: [
                              Container(
                                width: 40,
                                height: 40,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0xFFf59e0b).withOpacity(0.1),
                                ),
                                child: Icon(
                                  Icons.timer,
                                  color: Color(0xFFf59e0b),
                                  size: 20,
                                ),
                              ),
                              SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      '${session['duration_minutes']} minutes',
                                      style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        color: Color(0xFF1a1a2e),
                                        fontSize: 14,
                                      ),
                                    ),
                                    SizedBox(height: 2),
                                    Text(
                                      session['session_date'],
                                      style: TextStyle(
                                        color: Colors.grey[500],
                                        fontSize: 12,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ] else
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: Center(
                      child: Column(
                        children: [
                          Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Color(0xFF6366f1).withOpacity(0.1),
                            ),
                            child: Icon(
                              Icons.timer,
                              size: 28,
                              color: Color(0xFF6366f1),
                            ),
                          ),
                          SizedBox(height: 12),
                          Text(
                            'No sessions yet',
                            style: TextStyle(
                              color: Colors.grey[600],
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatCard(
      String label,
      String value,
      IconData icon,
      Color color,
      ) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
        border: Border.all(
          color: color.withOpacity(0.1),
          width: 1.5,
        ),
      ),
      padding: EdgeInsets.all(14.0),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, size: 24, color: color),
          ),
          SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: color,
            ),
          ),
          SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              color: Colors.grey[600],
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}