import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'config.dart';

class ProgressActivity extends StatefulWidget {
  final int userId;
  final String userName;

  ProgressActivity({required this.userId, required this.userName});

  @override
  _ProgressActivityState createState() => _ProgressActivityState();
}

class _ProgressActivityState extends State<ProgressActivity> {
  bool _isLoading = true;
  Map<String, dynamic> _progress = {};

  @override
  void initState() {
    super.initState();
    _fetchProgress();
  }

  Future<void> _fetchProgress() async {
    setState(() => _isLoading = true);

    try {
      final response = await http.get(
        Uri.parse('${Config.apiBaseUrl}get_progress.php?user_id=${widget.userId}'),
      );

      final data = json.decode(response.body);

      if (data['success']) {
        setState(() {
          _progress = data['progress'];
          _isLoading = false;
        });
      } else {
        _showError(data['message'] ?? 'Failed to load progress');
        setState(() => _isLoading = false);
      }
    } catch (e) {
      _showError('Connection error. Please try again.');
      setState(() => _isLoading = false);
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  String _formatDate(String? dateStr) {
    if (dateStr == null) return 'Never';
    try {
      final date = DateTime.parse(dateStr);
      return '${date.day}/${date.month}/${date.year}';
    } catch (e) {
      return dateStr;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF6366f1),
        elevation: 0,
        title: Text(
          'My Progress',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: Colors.white,
            letterSpacing: 0.3,
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: _isLoading
          ? Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF6366f1)),
        ),
      )
          : RefreshIndicator(
        onRefresh: _fetchProgress,
        color: Color(0xFF6366f1),
        child: SingleChildScrollView(
          physics: AlwaysScrollableScrollPhysics(),
          padding: EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // User Header
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF6366f1), Color(0xFF8b5cf6)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0xFF6366f1).withOpacity(0.3),
                      blurRadius: 20,
                      offset: Offset(0, 8),
                    ),
                  ],
                ),
                padding: EdgeInsets.all(24.0),
                child: Row(
                  children: [
                    Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white.withOpacity(0.25),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.5),
                          width: 2,
                        ),
                      ),
                      child: Center(
                        child: Text(
                          widget.userName[0].toUpperCase(),
                          style: TextStyle(
                            fontSize: 40,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.userName,
                            style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.w800,
                              color: Colors.white,
                              letterSpacing: 0.3,
                            ),
                          ),
                          SizedBox(height: 8),
                          Row(
                            children: [
                              Icon(
                                Icons.calendar_today,
                                size: 14,
                                color: Colors.white.withOpacity(0.8),
                              ),
                              SizedBox(width: 6),
                              Text(
                                'Last Study: ${_formatDate(_progress['last_study_date'])}',
                                style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.white.withOpacity(0.85),
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 32),

              // Overall Statistics
              Text(
                'Study Statistics',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF1a1a2e),
                  letterSpacing: 0.3,
                ),
              ),
              SizedBox(height: 16),

              // Notes Progress
              _buildProgressCard(
                'Notes Created',
                '${_progress['total_notes'] ?? 0}',
                Icons.note_outlined,
                Color(0xFF6366f1),
                'Keep writing to enhance your learning!',
              ),
              SizedBox(height: 12),

              // Flashcards Progress
              _buildProgressCard(
                'Flashcards Generated',
                '${_progress['total_flashcards'] ?? 0}',
                Icons.style_outlined,
                Color(0xFF10b981),
                'Review flashcards to improve memory retention',
              ),
              SizedBox(height: 12),

              // Pomodoro Progress
              _buildProgressCard(
                'Focus Time',
                '${_progress['total_pomodoro_minutes'] ?? 0} min',
                Icons.timer_outlined,
                Color(0xFFf59e0b),
                'Stay focused and productive!',
              ),
              SizedBox(height: 12),

              // Tasks Progress
              _buildProgressCard(
                'Tasks Completed',
                '${((_progress['total_tasks'] ?? 0) - (_progress['pending_tasks'] ?? 0))}/${_progress['total_tasks'] ?? 0}',
                Icons.task_outlined,
                Color(0xFF8b5cf6),
                'Keep completing your tasks!',
              ),
              SizedBox(height: 32),

              // Achievements Section
              Text(
                'Achievements',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF1a1a2e),
                  letterSpacing: 0.3,
                ),
              ),
              SizedBox(height: 16),
              _buildAchievements(),

              SizedBox(height: 32),

              // Study Tips
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Color(0xFF8b5cf6).withOpacity(0.1),
                      Color(0xFF6366f1).withOpacity(0.05),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: Color(0xFF8b5cf6).withOpacity(0.2),
                    width: 1.5,
                  ),
                ),
                padding: EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: Color(0xFF8b5cf6).withOpacity(0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            Icons.lightbulb,
                            color: Color(0xFF8b5cf6),
                            size: 24,
                          ),
                        ),
                        SizedBox(width: 12),
                        Text(
                          'Study Tip',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF8b5cf6),
                            letterSpacing: 0.2,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 12),
                    Text(
                      'Take regular breaks using the Pomodoro technique. Studies show that 25-minute focused sessions followed by 5-minute breaks improve concentration and retention!',
                      style: TextStyle(
                        fontSize: 14,
                        color: Color(0xFF4b5563),
                        height: 1.6,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProgressCard(
      String title,
      String value,
      IconData icon,
      Color color,
      String subtitle,
      ) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 12,
            offset: Offset(0, 4),
          ),
        ],
        border: Border.all(
          color: color.withOpacity(0.1),
          width: 1.5,
        ),
      ),
      padding: EdgeInsets.all(16.0),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, size: 32, color: color),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.2,
                  ),
                ),
                SizedBox(height: 6),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: color,
                    letterSpacing: 0.3,
                  ),
                ),
                SizedBox(height: 6),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[500],
                    fontWeight: FontWeight.w500,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAchievements() {
    final notes = _progress['total_notes'] ?? 0;
    final flashcards = _progress['total_flashcards'] ?? 0;
    final minutes = _progress['total_pomodoro_minutes'] ?? 0;
    final tasks = _progress['total_tasks'] ?? 0;

    List<Map<String, dynamic>> achievements = [
      {
        'title': 'First Steps',
        'description': 'Create your first note',
        'achieved': notes > 0,
        'icon': Icons.create,
        'color': Colors.blue,
      },
      {
        'title': 'Note Master',
        'description': 'Create 10 notes',
        'achieved': notes >= 10,
        'icon': Icons.note_alt,
        'color': Colors.blue,
      },
      {
        'title': 'Flashcard Beginner',
        'description': 'Generate 5 flashcards',
        'achieved': flashcards >= 5,
        'icon': Icons.style,
        'color': Colors.green,
      },
      {
        'title': 'Focus Novice',
        'description': 'Complete 1 hour of Pomodoro',
        'achieved': minutes >= 60,
        'icon': Icons.timer,
        'color': Colors.orange,
      },
      {
        'title': 'Dedicated Learner',
        'description': 'Complete 5 hours of Pomodoro',
        'achieved': minutes >= 300,
        'icon': Icons.emoji_events,
        'color': Colors.amber,
      },
      {
        'title': 'Task Master',
        'description': 'Complete 5 tasks',
        'achieved': tasks >= 5,
        'icon': Icons.task_alt,
        'color': Colors.purple,
      },
    ];

    return Column(
      children: achievements.map((achievement) {
        return Container(
          margin: EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: achievement['achieved']
                ? achievement['color'].withOpacity(0.08)
                : Colors.grey.withOpacity(0.05),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: achievement['achieved']
                  ? achievement['color'].withOpacity(0.15)
                  : Colors.grey.withOpacity(0.1),
              width: 1.5,
            ),
          ),
          child: Padding(
            padding: EdgeInsets.all(14.0),
            child: Row(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: achievement['achieved']
                        ? achievement['color'].withOpacity(0.2)
                        : Colors.grey.withOpacity(0.1),
                  ),
                  child: Icon(
                    achievement['achieved'] ? Icons.check : achievement['icon'],
                    color: achievement['achieved']
                        ? achievement['color']
                        : Colors.grey[400],
                    size: 26,
                  ),
                ),
                SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        achievement['title'],
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 14,
                          color: achievement['achieved']
                              ? Color(0xFF1a1a2e)
                              : Colors.grey[500],
                          letterSpacing: 0.2,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        achievement['description'],
                        style: TextStyle(
                          fontSize: 12,
                          color: achievement['achieved']
                              ? Colors.grey[600]
                              : Colors.grey[400],
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(width: 8),
                Icon(
                  achievement['achieved'] ? Icons.emoji_events : Icons.lock_outlined,
                  color: achievement['achieved']
                      ? Colors.amber[600]
                      : Colors.grey[400],
                  size: 20,
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }
}