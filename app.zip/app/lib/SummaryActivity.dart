import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'config.dart';

class SummaryActivity extends StatefulWidget {
  final int noteId;
  final String noteTitle;
  final String noteContent;

  const SummaryActivity({
    Key? key,
    required this.noteId,
    required this.noteTitle,
    required this.noteContent,
  }) : super(key: key);

  @override
  State<SummaryActivity> createState() => _SummaryActivityState();
}

class _SummaryActivityState extends State<SummaryActivity> {
  bool isLoading = false;
  bool isGenerating = false;
  String? summaryText;
  String? errorMessage;
  List<dynamic> existingSummaries = [];

  // OpenRouter API configuration
  static const String openRouterApiKey = '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';
  static const String openRouterUrl = 'https://openrouter.ai/api/v1/chat/completions';

  // Use a reliable free model - try these alternatives if one doesn't work:
  // 'meta-llama/llama-3.2-3b-instruct:free'
  // 'google/gemma-2-9b-it:free'
  // 'qwen/qwen-2-7b-instruct:free'
  // 'mistralai/mistral-7b-instruct:free'
  static const String aiModel = 'meta-llama/llama-3.2-3b-instruct:free';

  @override
  void initState() {
    super.initState();
    fetchExistingSummaries();
  }

  // Fetch existing summaries from database
  Future<void> fetchExistingSummaries() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final response = await http.get(
        Uri.parse('${Config.apiBaseUrl}get_summaries.php?note_id=${widget.noteId}'),
      ).timeout(Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          setState(() {
            existingSummaries = data['summaries'] ?? [];
            if (existingSummaries.isNotEmpty) {
              summaryText = existingSummaries[0]['summary_text'];
            }
          });
        } else {
          setState(() {
            errorMessage = data['message'] ?? 'Failed to fetch summaries';
          });
        }
      } else {
        setState(() {
          errorMessage = 'Server error: ${response.statusCode}';
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = 'Error: $e';
      });
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  // Generate summary using OpenRouter AI
  Future<void> generateAISummary() async {
    if (widget.noteContent.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Note content is empty')),
      );
      return;
    }

    setState(() {
      isGenerating = true;
      errorMessage = null;
    });

    try {
      print('Calling OpenRouter API...');
      print('Model: $aiModel');
      print('Content length: ${widget.noteContent.length}');

      // Call OpenRouter API
      final aiResponse = await http.post(
        Uri.parse(openRouterUrl),
        headers: {
          'Authorization': 'Bearer $openRouterApiKey',
          'Content-Type': 'application/json',
          'HTTP-Referer': 'https://study-companion.app',
          'X-Title': 'AI Study Companion',
        },
        body: json.encode({
          'model': aiModel,
          'messages': [
            {
              'role': 'system',
              'content': 'You are a helpful study assistant. Create concise, clear summaries of study notes that highlight key concepts, main ideas, and important details. Keep summaries focused and easy to understand. Respond with only the summary text.'
            },
            {
              'role': 'user',
              'content': 'Please summarize the following study notes:\n\n${widget.noteContent}'
            }
          ],
          'max_tokens': 500,
          'temperature': 0.7,
        }),
      ).timeout(Duration(seconds: 60));

      print('Response status: ${aiResponse.statusCode}');
      print('Response body: ${aiResponse.body}');

      if (aiResponse.statusCode == 200) {
        final aiData = json.decode(aiResponse.body);

        if (aiData['choices'] != null && aiData['choices'].isNotEmpty) {
          String generatedSummary = aiData['choices'][0]['message']['content'];

          // Clean up the summary (remove any thinking tags if present)
          generatedSummary = generatedSummary
              .replaceAll(RegExp(r'<think>.*?</think>', dotAll: true), '')
              .trim();

          // Save summary to database
          await saveSummaryToDatabase(generatedSummary);
        } else {
          throw Exception('Invalid response format from AI');
        }
      } else if (aiResponse.statusCode == 401) {
        throw Exception('Invalid API key');
      } else if (aiResponse.statusCode == 402) {
        throw Exception('No credits remaining');
      } else if (aiResponse.statusCode == 429) {
        throw Exception('Rate limit exceeded. Please wait and try again.');
      } else if (aiResponse.statusCode == 404) {
        throw Exception('Model not found. Try a different model.');
      } else {
        // Try to parse error message
        try {
          final errorData = json.decode(aiResponse.body);
          throw Exception(errorData['error']?['message'] ?? 'API error: ${aiResponse.statusCode}');
        } catch (e) {
          throw Exception('API error: ${aiResponse.statusCode}');
        }
      }
    } catch (e) {
      print('Error generating summary: $e');
      setState(() {
        errorMessage = '$e';
        isGenerating = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('$e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  // Save summary to database via PHP
  Future<void> saveSummaryToDatabase(String summary) async {
    try {
      final response = await http.post(
        Uri.parse('${Config.apiBaseUrl}generate_summary.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'note_id': widget.noteId,
          'summary_text': summary,
        }),
      ).timeout(Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          setState(() {
            summaryText = summary;
            isGenerating = false;
          });
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Summary generated successfully!'),
              backgroundColor: Colors.green,
            ),
          );
          fetchExistingSummaries(); // Refresh list
        } else {
          throw Exception(data['message'] ?? 'Failed to save summary');
        }
      } else {
        throw Exception('Server error: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        errorMessage = 'Failed to save summary: $e';
        isGenerating = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error saving: $e')),
      );
    }
  }

  // Delete summary
  Future<void> deleteSummary(int summaryId) async {
    try {
      final response = await http.post(
        Uri.parse('${Config.apiBaseUrl}generate_summary.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'action': 'delete',
          'summary_id': summaryId,
        }),
      ).timeout(Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Summary deleted')),
          );
          fetchExistingSummaries();
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  // Show full summary in a dialog
  void _showFullSummary(String fullSummary) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF8b5cf6).withOpacity(0.05),
                Colors.white,
              ],
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Header
              Container(
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF8b5cf6), Color(0xFF7c3aed)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20),
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.auto_awesome,
                      color: Colors.white,
                      size: 28,
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Full Summary',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                          letterSpacing: 0.3,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Icon(
                        Icons.close,
                        color: Colors.white,
                        size: 24,
                      ),
                    ),
                  ],
                ),
              ),
              // Content
              Flexible(
                child: SingleChildScrollView(
                  padding: EdgeInsets.all(20),
                  child: Text(
                    fullSummary,
                    style: TextStyle(
                      fontSize: 15,
                      height: 1.8,
                      color: Color(0xFF4b5563),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
              // Footer Button
              Padding(
                padding: EdgeInsets.all(16),
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFF8b5cf6), Color(0xFF7c3aed)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0xFF8b5cf6).withOpacity(0.3),
                        blurRadius: 12,
                        offset: Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () => Navigator.pop(context),
                      borderRadius: BorderRadius.circular(12),
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 14),
                        child: Center(
                          child: Text(
                            'Close',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF8b5cf6),
        elevation: 0,
        title: Text(
          'AI Summary',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: Colors.white,
            letterSpacing: 0.3,
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context, true),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF8b5cf6).withOpacity(0.08), Colors.white],
          ),
        ),
        child: isLoading
            ? Center(
          child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF8b5cf6)),
          ),
        )
            : SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Note Title Card
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 12,
                      offset: Offset(0, 4),
                    ),
                  ],
                  border: Border.all(
                    color: Color(0xFF8b5cf6).withOpacity(0.1),
                    width: 1.5,
                  ),
                ),
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: Color(0xFF8b5cf6).withOpacity(0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            Icons.note_outlined,
                            color: Color(0xFF8b5cf6),
                            size: 22,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            widget.noteTitle,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              color: Color(0xFF1a1a2e),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Original Content:',
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 12,
                        color: Colors.grey[600],
                        letterSpacing: 0.2,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      widget.noteContent,
                      style: TextStyle(
                        fontSize: 13,
                        height: 1.6,
                        color: Colors.grey[700],
                      ),
                      maxLines: 5,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 28),

              // Generate Button
              Center(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFF8b5cf6), Color(0xFF7c3aed)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0xFF8b5cf6).withOpacity(0.4),
                        blurRadius: 16,
                        offset: Offset(0, 8),
                      ),
                    ],
                  ),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: isGenerating ? null : generateAISummary,
                      borderRadius: BorderRadius.circular(14),
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (isGenerating)
                              SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                ),
                              )
                            else
                              Icon(Icons.auto_awesome, color: Colors.white),
                            const SizedBox(width: 10),
                            Text(
                              isGenerating
                                  ? 'Generating...'
                                  : existingSummaries.isEmpty
                                  ? 'Generate AI Summary'
                                  : 'Regenerate Summary',
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                                letterSpacing: 0.3,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 28),

              // Error Message
              if (errorMessage != null)
                Container(
                  decoration: BoxDecoration(
                    color: Colors.red.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: Colors.red.withOpacity(0.2),
                      width: 1.5,
                    ),
                  ),
                  padding: const EdgeInsets.all(14.0),
                  child: Row(
                    children: [
                      Icon(Icons.error_outline, color: Colors.red, size: 22),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          errorMessage!,
                          style: TextStyle(
                            color: Colors.red[900],
                            fontWeight: FontWeight.w500,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

              // Summary Display
              if (summaryText != null) ...[
                SizedBox(height: errorMessage != null ? 24 : 0),
                Text(
                  'AI Generated Summary',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF1a1a2e),
                    letterSpacing: 0.3,
                  ),
                ),
                const SizedBox(height: 12),
                GestureDetector(
                  onTap: () => _showFullSummary(summaryText!),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0xFF8b5cf6).withOpacity(0.15),
                          blurRadius: 16,
                          offset: Offset(0, 6),
                        ),
                      ],
                      border: Border.all(
                        color: Color(0xFF8b5cf6).withOpacity(0.2),
                        width: 1.5,
                      ),
                    ),
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(
                              Icons.auto_awesome,
                              color: Color(0xFF8b5cf6),
                              size: 24,
                            ),
                            const SizedBox(width: 10),
                            Text(
                              'Summary',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                color: Color(0xFF8b5cf6),
                                letterSpacing: 0.2,
                              ),
                            ),
                          ],
                        ),
                        Divider(
                          height: 20,
                          color: Color(0xFF8b5cf6).withOpacity(0.1),
                        ),
                        Text(
                          summaryText!,
                          style: TextStyle(
                            fontSize: 14,
                            height: 1.7,
                            color: Color(0xFF4b5563),
                            fontWeight: FontWeight.w500,
                          ),
                          maxLines: 4,
                          overflow: TextOverflow.ellipsis,
                        ),
                        SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                color: Color(0xFF8b5cf6).withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              child: Row(
                                children: [
                                  Text(
                                    'View Full',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w700,
                                      color: Color(0xFF8b5cf6),
                                      letterSpacing: 0.2,
                                    ),
                                  ),
                                  SizedBox(width: 4),
                                  Icon(
                                    Icons.arrow_forward,
                                    size: 14,
                                    color: Color(0xFF8b5cf6),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],

              // All Summaries History
              if (existingSummaries.length > 1) ...[
                const SizedBox(height: 32),
                Text(
                  'Previous Summaries',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF1a1a2e),
                    letterSpacing: 0.3,
                  ),
                ),
                const SizedBox(height: 12),
                ...existingSummaries.skip(1).map((summary) {
                  return GestureDetector(
                    onTap: () => _showFullSummary(summary['summary_text']),
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.04),
                            blurRadius: 10,
                            offset: Offset(0, 2),
                          ),
                        ],
                        border: Border.all(
                          color: Colors.grey.withOpacity(0.1),
                          width: 1,
                        ),
                      ),
                      child: Padding(
                        padding: EdgeInsets.all(14.0),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: Colors.grey.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Icon(
                                Icons.history,
                                color: Colors.grey[600],
                                size: 20,
                              ),
                            ),
                            SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    summary['summary_text'],
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                      color: Color(0xFF1a1a2e),
                                    ),
                                  ),
                                  SizedBox(height: 6),
                                  Text(
                                    'Created: ${summary['created_at']}',
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: Colors.grey[500],
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            IconButton(
                              icon: Icon(Icons.delete_outline, color: Colors.red, size: 20),
                              onPressed: () => deleteSummary(
                                int.parse(summary['summary_id'].toString()),
                              ),
                              visualDensity: VisualDensity.compact,
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ],
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}