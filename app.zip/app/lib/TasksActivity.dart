import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'config.dart';

class TasksActivity extends StatefulWidget {
  final int userId;

  TasksActivity({required this.userId});

  @override
  _TasksActivityState createState() => _TasksActivityState();
}

class _TasksActivityState extends State<TasksActivity> {
  List<dynamic> _tasks = [];
  bool _isLoading = true;
  int _completedCount = 0;
  int _pendingCount = 0;

  @override
  void initState() {
    super.initState();
    _fetchTasks();
  }

  Future<void> _fetchTasks() async {
    setState(() => _isLoading = true);

    try {
      final response = await http.get(
        Uri.parse('${Config.apiBaseUrl}get_tasks.php?user_id=${widget.userId}'),
      );

      final data = json.decode(response.body);

      if (data['success']) {
        setState(() {
          _tasks = data['tasks'];
          _completedCount = data['completed_count'];
          _pendingCount = data['pending_count'];
          _isLoading = false;
        });
      } else {
        _showError(data['message'] ?? 'Failed to load tasks');
        setState(() => _isLoading = false);
      }
    } catch (e) {
      _showError('Connection error. Please try again.');
      setState(() => _isLoading = false);
    }
  }

  Future<void> _toggleTaskCompletion(int taskId, bool isCompleted) async {
    try {
      final response = await http.post(
        Uri.parse('${Config.apiBaseUrl}update_task.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'task_id': taskId,
          'is_completed': isCompleted ? 1 : 0,
        }),
      );

      final data = json.decode(response.body);

      if (data['success']) {
        _fetchTasks();
      } else {
        _showError(data['message'] ?? 'Failed to update task');
      }
    } catch (e) {
      _showError('Connection error. Please try again.');
    }
  }

  Future<void> _deleteTask(int taskId) async {
    try {
      final response = await http.post(
        Uri.parse('${Config.apiBaseUrl}delete_task.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'task_id': taskId,
          'user_id': widget.userId,
        }),
      );

      final data = json.decode(response.body);

      if (data['success']) {
        _showSuccess('Task deleted successfully');
        _fetchTasks();
      } else {
        _showError(data['message'] ?? 'Failed to delete task');
      }
    } catch (e) {
      _showError('Connection error. Please try again.');
    }
  }

  void _showAddTaskDialog() {
    final titleController = TextEditingController();
    final descriptionController = TextEditingController();
    final detailsController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: Text(
          'Add New Task',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: Color(0xFF1a1a2e),
          ),
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildTextField(titleController, 'Title'),
              SizedBox(height: 12),
              _buildTextField(descriptionController, 'Description (optional)', maxLines: 2),
              SizedBox(height: 12),
              _buildTextField(detailsController, 'Details (optional)', maxLines: 3),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            ),
            child: Text(
              'Cancel',
              style: TextStyle(
                color: Colors.grey[600],
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () async {
              if (titleController.text.trim().isEmpty) {
                _showError('Please enter a title');
                return;
              }

              Navigator.pop(context);
              await _addTask(
                titleController.text.trim(),
                descriptionController.text.trim(),
                detailsController.text.trim(),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Color(0xFF6366f1),
              padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: Text(
              'Add',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showEditTaskDialog(Map<String, dynamic> task) {
    final titleController = TextEditingController(text: task['title']);
    final descriptionController = TextEditingController(text: task['description'] ?? '');
    final detailsController = TextEditingController(text: task['details'] ?? '');

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: Text(
          'Edit Task',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: Color(0xFF1a1a2e),
          ),
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildTextField(titleController, 'Title'),
              SizedBox(height: 12),
              _buildTextField(descriptionController, 'Description (optional)', maxLines: 2),
              SizedBox(height: 12),
              _buildTextField(detailsController, 'Details (optional)', maxLines: 3),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            ),
            child: Text(
              'Cancel',
              style: TextStyle(
                color: Colors.grey[600],
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () async {
              if (titleController.text.trim().isEmpty) {
                _showError('Please enter a title');
                return;
              }

              Navigator.pop(context);
              await _updateTask(
                int.parse(task['task_id'].toString()),
                titleController.text.trim(),
                descriptionController.text.trim(),
                detailsController.text.trim(),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Color(0xFF6366f1),
              padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: Text(
              'Save',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String label, {int maxLines = 1}) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(
          color: Colors.grey[600],
          fontWeight: FontWeight.w500,
        ),
        contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey[300]!),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Color(0xFF6366f1), width: 2),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey[300]!),
        ),
      ),
    );
  }

  Future<void> _addTask(String title, String description, String details) async {
    try {
      final response = await http.post(
        Uri.parse('${Config.apiBaseUrl}add_task.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'user_id': widget.userId,
          'title': title,
          'description': description,
          'details': details,
        }),
      );

      final data = json.decode(response.body);

      if (data['success']) {
        _showSuccess('Task created successfully');
        _fetchTasks();
      } else {
        _showError(data['message'] ?? 'Failed to add task');
      }
    } catch (e) {
      _showError('Connection error. Please try again.');
    }
  }

  Future<void> _updateTask(int taskId, String title, String description, String details) async {
    try {
      final response = await http.post(
        Uri.parse('${Config.apiBaseUrl}update_task.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'task_id': taskId,
          'title': title,
          'description': description,
          'details': details,
        }),
      );

      final data = json.decode(response.body);

      if (data['success']) {
        _showSuccess('Task updated successfully');
        _fetchTasks();
      } else {
        _showError(data['message'] ?? 'Failed to update task');
      }
    } catch (e) {
      _showError('Connection error. Please try again.');
    }
  }

  void _confirmDelete(int taskId, String title) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: Text(
          'Delete Task?',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: Color(0xFF1a1a2e),
          ),
        ),
        content: Text(
          'Are you sure you want to delete "$title"?',
          style: TextStyle(color: Colors.grey[600]),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            ),
            child: Text(
              'Cancel',
              style: TextStyle(
                color: Colors.grey[600],
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _deleteTask(taskId);
            },
            style: TextButton.styleFrom(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            ),
            child: Text(
              'Delete',
              style: TextStyle(
                color: Colors.red,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _isLoading
          ? Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF6366f1)),
        ),
      )
          : SingleChildScrollView(
        physics: AlwaysScrollableScrollPhysics(),
        child: RefreshIndicator(
          onRefresh: _fetchTasks,
          color: Color(0xFF6366f1),
          child: Column(
            children: [
              // Statistics Cards
              Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Overview',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF1a1a2e),
                        letterSpacing: 0.2,
                      ),
                    ),
                    SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: _buildStatCard(
                            'Pending',
                            _pendingCount.toString(),
                            Icons.pending_actions,
                            Color(0xFFf59e0b),
                          ),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: _buildStatCard(
                            'Completed',
                            _completedCount.toString(),
                            Icons.check_circle,
                            Color(0xFF10b981),
                          ),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: _buildStatCard(
                            'Total',
                            _tasks.length.toString(),
                            Icons.task_alt,
                            Color(0xFF6366f1),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // Tasks List
              if (_tasks.isEmpty)
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 64.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Color(0xFF6366f1).withOpacity(0.1),
                        ),
                        child: Icon(
                          Icons.task_alt,
                          size: 40,
                          color: Color(0xFF6366f1),
                        ),
                      ),
                      SizedBox(height: 16),
                      Text(
                        'No tasks yet',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF1a1a2e),
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Tap + to create your first task',
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                )
              else
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'My Tasks',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF1a1a2e),
                        ),
                      ),
                      SizedBox(height: 12),
                      ListView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: _tasks.length,
                        itemBuilder: (context, index) {
                          final task = _tasks[index];
                          final isCompleted = task['is_completed'] == 1;

                          return _buildTaskCard(task, isCompleted);
                        },
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddTaskDialog,
        backgroundColor: Color(0xFF6366f1),
        child: Icon(Icons.add, color: Colors.white),
        elevation: 8,
      ),
    );
  }

  Widget _buildStatCard(String label, String value, IconData icon, Color color) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
        border: Border.all(
          color: color.withOpacity(0.1),
          width: 1.5,
        ),
      ),
      padding: EdgeInsets.all(12.0),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, size: 24, color: color),
          ),
          SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w800,
              color: color,
            ),
          ),
          SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              color: Colors.grey[600],
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTaskCard(Map<String, dynamic> task, bool isCompleted) {
    return Container(
      margin: EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
        border: Border.all(
          color: Colors.grey.withOpacity(0.1),
          width: 1,
        ),
      ),
      child: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: EdgeInsets.all(2),
                  child: Checkbox(
                    value: isCompleted,
                    activeColor: Color(0xFF6366f1),
                    onChanged: (value) {
                      _toggleTaskCompletion(
                        int.parse(task['task_id'].toString()),
                        value ?? false,
                      );
                    },
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(top: 4),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          task['title'],
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 15,
                            decoration: isCompleted
                                ? TextDecoration.lineThrough
                                : null,
                            color: isCompleted
                                ? Colors.grey[500]
                                : Color(0xFF1a1a2e),
                          ),
                        ),
                        if (task['description'] != null &&
                            task['description'].isNotEmpty) ...[
                          SizedBox(height: 4),
                          Text(
                            task['description'],
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 13,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
                PopupMenuButton(
                  itemBuilder: (BuildContext context) => [
                    PopupMenuItem(
                      child: Row(
                        children: [
                          Icon(Icons.edit, color: Color(0xFF6366f1), size: 18),
                          SizedBox(width: 8),
                          Text(
                            'Edit',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                      value: 'edit',
                    ),
                    PopupMenuItem(
                      child: Row(
                        children: [
                          Icon(Icons.delete, color: Colors.red, size: 18),
                          SizedBox(width: 8),
                          Text(
                            'Delete',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                      value: 'delete',
                    ),
                  ],
                  onSelected: (value) {
                    if (value == 'edit') {
                      _showEditTaskDialog(task);
                    } else if (value == 'delete') {
                      _confirmDelete(
                        int.parse(task['task_id'].toString()),
                        task['title'],
                      );
                    }
                  },
                ),
              ],
            ),
            if (task['details'] != null && task['details'].isNotEmpty) ...[
              SizedBox(height: 8),
              Padding(
                padding: EdgeInsets.only(left: 48),
                child: Text(
                  task['details'],
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[500],
                  ),
                ),
              ),
            ],
            if (task['due_date'] != null) ...[
              SizedBox(height: 8),
              Padding(
                padding: EdgeInsets.only(left: 48),
                child: Row(
                  children: [
                    Icon(Icons.calendar_today,
                        size: 12, color: Colors.grey[400]),
                    SizedBox(width: 4),
                    Text(
                      'Due: ${task['due_date']}',
                      style: TextStyle(
                        fontSize: 11,
                        color: Colors.grey[500],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}