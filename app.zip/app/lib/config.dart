 class Config{
  static const String apiBaseUrl ='http://localhost/hosting/';

 }