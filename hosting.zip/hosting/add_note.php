<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $user_id = isset($data['user_id']) ? (int)$data['user_id'] : 0;
    $title = $data['title'] ?? '';
    $content = $data['content'] ?? '';
    
    if (empty($user_id) || empty($title) || empty($content)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'User ID, title, and content are required']);
        exit;
    }
    
    $stmt = $conn->prepare("INSERT INTO notes (user_id, title, content, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())");
    
    if (!$stmt) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
        exit;
    }
    
    $stmt->bind_param("iss", $user_id, $title, $content);
    
    if ($stmt->execute()) {
        $note_id = $conn->insert_id;
        
        // Update user progress
        $progress_stmt = $conn->prepare("UPDATE progress SET total_notes = total_notes + 1 WHERE user_id = ?");
        if ($progress_stmt) {
            $progress_stmt->bind_param("i", $user_id);
            $progress_stmt->execute();
            $progress_stmt->close();
        }
        
        echo json_encode([
            'success' => true, 
            'message' => 'Note created successfully',
            'note_id' => $note_id
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to create note: ' . $stmt->error]);
    }
    
    $stmt->close();
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?>