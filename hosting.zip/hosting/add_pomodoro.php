<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $user_id = $data['user_id'] ?? '';
    $duration_minutes = $data['duration_minutes'] ?? '';
    
    if (empty($user_id) || empty($duration_minutes)) {
        echo json_encode(['success' => false, 'message' => 'User ID and duration are required']);
        exit;
    }
    
    $stmt = $conn->prepare("INSERT INTO pomodoro_sessions (user_id, duration_minutes) VALUES (?, ?)");
    $stmt->bind_param("ii", $user_id, $duration_minutes);
    
    if ($stmt->execute()) {
        $session_id = $conn->insert_id;
        
        // Update user progress
        $progress_stmt = $conn->prepare("UPDATE progress SET total_pomodoro_minutes = total_pomodoro_minutes + ?, last_study_date = NOW() WHERE user_id = ?");
        $progress_stmt->bind_param("ii", $duration_minutes, $user_id);
        $progress_stmt->execute();
        $progress_stmt->close();
        
        echo json_encode(['success' => true, 'message' => 'Pomodoro session saved successfully', 'session_id' => $session_id]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to save Pomodoro session']);
    }
    
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?>