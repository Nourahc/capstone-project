<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $user_id = $data['user_id'] ?? '';
    $title = $data['title'] ?? '';
    $description = $data['description'] ?? '';
    $details = $data['details'] ?? '';
    $due_date = $data['due_date'] ?? null;
    
    if (empty($user_id) || empty($title)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'User ID and title are required']);
        exit;
    }
    
    try {
        // Fixed query - removed note_id since tasks table doesn't have that column
        $stmt = $conn->prepare("INSERT INTO tasks (user_id, title, description, details, due_date) VALUES (?, ?, ?, ?, ?)");
        
        if (!$stmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        
        // Ensure proper type casting
        $user_id = intval($user_id);
        
        $stmt->bind_param("issss", $user_id, $title, $description, $details, $due_date);
        
        if (!$stmt->execute()) {
            throw new Exception("Execute failed: " . $stmt->error);
        }
        
        $task_id = $conn->insert_id;
        
        http_response_code(201);
        echo json_encode([
            'success' => true,
            'message' => 'Task added successfully',
            'task_id' => $task_id
        ]);
        
        $stmt->close();
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Error adding task: ' . $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?>