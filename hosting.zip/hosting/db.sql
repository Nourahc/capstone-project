-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tai_study_companion`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  `description` text,
  `color_code` varchar(7) DEFAULT '#3498db',
  `icon` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `category_name` (`category_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `description`, `color_code`, `icon`, `created_at`) VALUES
(1, 'Java Basics', 'Fundamentals of Java programming language', '#e67e22', 'code', '2025-11-08 10:34:27'),
(2, 'Web Development', 'HTML, CSS, and JavaScript essentials', '#3498db', 'globe', '2025-11-08 10:34:27'),
(3, 'Database Systems', 'Concepts of SQL and relational databases', '#2ecc71', 'database', '2025-11-08 10:34:27'),
(4, 'AI Concepts', 'Introduction to Artificial Intelligence', '#9b59b6', 'brain', '2025-11-08 10:34:27');

-- --------------------------------------------------------

--
-- Table structure for table `flashcards`
--

DROP TABLE IF EXISTS `flashcards`;
CREATE TABLE IF NOT EXISTS `flashcards` (
  `flashcard_id` int NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL DEFAULT 'General',
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `hint` text,
  `status` enum('new','learning','learned') DEFAULT 'new',
  `difficulty` enum('easy','medium','hard') DEFAULT 'medium',
  `study_count` int DEFAULT '0',
  `times_correct` int DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`flashcard_id`),
  KEY `idx_category` (`category`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 ;

--
-- Dumping data for table `flashcards`
--

INSERT INTO `flashcards` (`flashcard_id`, `category`, `question`, `answer`, `hint`, `status`, `difficulty`, `study_count`, `times_correct`, `created_at`, `updated_at`) VALUES
(1, 'Java Basics', 'What is JVM?', 'Java Virtual Machine executes Java bytecode.', 'Runs compiled Java programs', 'new', 'medium', 0, 0, '2025-11-08 10:34:27', '2025-11-08 10:34:27'),
(2, 'Java Basics', 'What is JDK?', 'Java Development Kit, includes JRE and tools.', 'Used for developing Java applications', 'new', 'medium', 0, 0, '2025-11-08 10:34:27', '2025-11-08 10:34:27'),
(3, 'Java Basics', 'Difference between JDK and JRE?', 'JDK includes JRE + development tools.', 'JDK = JRE + compiler', 'new', 'medium', 0, 0, '2025-11-08 10:34:27', '2025-11-08 10:34:27'),
(4, 'Java Basics', 'What is a class in Java?', 'A template or blueprint for objects.', 'Used to create objects', 'new', 'medium', 0, 0, '2025-11-08 10:34:27', '2025-11-08 10:34:27'),
(5, 'Java Basics', 'What is inheritance?', 'Mechanism to acquire properties of another class.', 'Keyword: extends', 'new', 'medium', 0, 0, '2025-11-08 10:34:27', '2025-11-08 10:34:27'),
(6, 'Java Basics', 'What is polymorphism?', 'Ability of object to take many forms.', 'Method overriding and overloading', 'new', 'medium', 0, 0, '2025-11-08 10:34:27', '2025-11-08 10:34:27'),
(7, 'Java Basics', 'What is encapsulation?', 'Wrapping data and code together.', 'Private variables with getters/setters', 'new', 'medium', 0, 0, '2025-11-08 10:34:27', '2025-11-08 10:34:27'),
(8, 'Java Basics', 'What is abstraction?', 'Hiding implementation details.', 'Abstract classes and interfaces', 'new', 'medium', 0, 0, '2025-11-08 10:34:27', '2025-11-08 10:34:27'),
(9, 'Java Basics', 'What is a constructor?', 'A special method to initialize objects.', 'Same name as class', 'new', 'medium', 0, 0, '2025-11-08 10:34:27', '2025-11-08 10:34:27'),
(10, 'Java Basics', 'What is an interface?', 'Abstract type with abstract methods only.', 'Implemented using \"implements\"', 'new', 'medium', 0, 0, '2025-11-08 10:34:27', '2025-11-08 10:34:27'),
(11, 'Web Development', 'What does HTML stand for?', 'HyperText Markup Language.', 'Defines web page structure', 'learned', 'medium', 2, 2, '2025-11-08 10:34:28', '2025-11-09 16:32:43'),
(12, 'Web Development', 'What is CSS used for?', 'Cascading Style Sheets, for styling HTML.', 'Controls layout and design', 'learned', 'medium', 2, 2, '2025-11-08 10:34:28', '2025-11-09 16:32:44'),
(13, 'Web Development', 'What is JavaScript?', 'A programming language for interactivity.', 'Used for dynamic behavior', 'learned', 'medium', 2, 2, '2025-11-08 10:34:28', '2025-11-09 16:32:43'),
(14, 'Web Development', 'What is a div tag?', 'Defines a division or section in HTML.', 'Common container element', 'learned', 'medium', 2, 2, '2025-11-08 10:34:28', '2025-11-09 16:32:44'),
(15, 'Web Development', 'What is Bootstrap?', 'A CSS framework for responsive design.', 'Contains prebuilt components', 'learned', 'medium', 2, 2, '2025-11-08 10:34:28', '2025-11-09 16:32:44'),
(16, 'Web Development', 'What is responsive design?', 'Adapts layout to screen size.', 'Uses media queries', 'learning', 'medium', 2, 1, '2025-11-08 10:34:28', '2025-11-09 16:32:42'),
(17, 'Web Development', 'What is DOM?', 'Document Object Model, represents HTML as objects.', 'JavaScript interacts with DOM', 'learned', 'medium', 2, 2, '2025-11-08 10:34:28', '2025-11-09 16:32:43'),
(18, 'Web Development', 'What is an API?', 'Application Programming Interface.', 'Connects front-end and back-end', 'learned', 'medium', 2, 2, '2025-11-08 10:34:28', '2025-11-09 16:32:41'),
(19, 'Web Development', 'What is AJAX?', 'Asynchronous JavaScript and XML.', 'Used for partial page updates', 'learned', 'medium', 2, 2, '2025-11-08 10:34:28', '2025-11-09 16:32:44'),
(20, 'Web Development', 'What is React?', 'A JS library for building UI components.', 'Developed by Facebook', 'learned', 'medium', 2, 2, '2025-11-08 10:34:28', '2025-11-09 16:32:43'),
(21, 'Database Systems', 'What is SQL?', 'Structured Query Language.', 'Used to manage databases', 'new', 'medium', 0, 0, '2025-11-08 10:34:28', '2025-11-08 10:34:28'),
(22, 'Database Systems', 'What is a primary key?', 'A unique identifier for records.', 'Prevents duplicate rows', 'new', 'medium', 0, 0, '2025-11-08 10:34:28', '2025-11-08 10:34:28'),
(23, 'Database Systems', 'What is a foreign key?', 'Links records between tables.', 'Maintains relationships', 'new', 'medium', 0, 0, '2025-11-08 10:34:28', '2025-11-08 10:34:28'),
(24, 'Database Systems', 'What is normalization?', 'Process to reduce data redundancy.', 'Improves consistency', 'new', 'medium', 0, 0, '2025-11-08 10:34:28', '2025-11-08 10:34:28'),
(25, 'Database Systems', 'What is a JOIN?', 'Combines rows from two or more tables.', 'INNER, LEFT, RIGHT joins', 'new', 'medium', 0, 0, '2025-11-08 10:34:28', '2025-11-08 10:34:28'),
(26, 'Database Systems', 'What is a transaction?', 'A unit of work performed in DB.', 'Ensures atomicity', 'new', 'medium', 0, 0, '2025-11-08 10:34:28', '2025-11-08 10:34:28'),
(27, 'Database Systems', 'What is an index?', 'Improves query performance.', 'Uses B-trees internally', 'learned', 'medium', 1, 1, '2025-11-08 10:34:28', '2025-11-09 16:28:19'),
(28, 'Database Systems', 'What is a view?', 'A virtual table based on query result.', 'Does not store data physically', 'new', 'medium', 0, 0, '2025-11-08 10:34:28', '2025-11-08 10:34:28'),
(29, 'Database Systems', 'What is a constraint?', 'Rules applied to data columns.', 'Examples: NOT NULL, UNIQUE', 'new', 'medium', 0, 0, '2025-11-08 10:34:28', '2025-11-08 10:34:28'),
(30, 'Database Systems', 'What is MySQL?', 'An open-source relational DBMS.', 'Used widely with PHP', 'learning', 'medium', 1, 0, '2025-11-08 10:34:28', '2025-11-09 16:28:25'),
(31, 'AI Concepts', 'What is AI?', 'Artificial Intelligence enables machines to mimic human behavior.', 'Machines that think', 'new', 'medium', 0, 0, '2025-11-08 10:34:28', '2025-11-08 10:34:28'),
(32, 'AI Concepts', 'What is Machine Learning?', 'A subset of AI that learns from data.', 'Uses algorithms like regression', 'new', 'medium', 0, 0, '2025-11-08 10:34:28', '2025-11-08 10:34:28'),
(33, 'AI Concepts', 'What is Deep Learning?', 'A subset of ML using neural networks.', 'Inspired by human brain', 'new', 'medium', 0, 0, '2025-11-08 10:34:28', '2025-11-08 10:34:28'),
(34, 'AI Concepts', 'What is NLP?', 'Natural Language Processing, for understanding human language.', 'Used in chatbots', 'new', 'medium', 0, 0, '2025-11-08 10:34:28', '2025-11-08 10:34:28'),
(35, 'AI Concepts', 'What is a dataset?', 'A collection of data used for training models.', 'Input for ML algorithms', 'new', 'medium', 0, 0, '2025-11-08 10:34:28', '2025-11-08 10:34:28'),
(36, 'AI Concepts', 'What is supervised learning?', 'Learning from labeled data.', 'Example: classification', 'new', 'medium', 0, 0, '2025-11-08 10:34:28', '2025-11-08 10:34:28'),
(37, 'AI Concepts', 'What is unsupervised learning?', 'Learning from unlabeled data.', 'Example: clustering', 'new', 'medium', 0, 0, '2025-11-08 10:34:28', '2025-11-08 10:34:28'),
(38, 'AI Concepts', 'What is reinforcement learning?', 'Learning by trial and reward.', 'Used in game AI', 'new', 'medium', 0, 0, '2025-11-08 10:34:28', '2025-11-08 10:34:28'),
(39, 'AI Concepts', 'What is overfitting?', 'Model performs well on training but poorly on new data.', 'Too specific', 'new', 'medium', 0, 0, '2025-11-08 10:34:28', '2025-11-08 10:34:28'),
(40, 'AI Concepts', 'What is AI ethics?', 'Moral implications of using AI.', 'Ensures fairness and transparency', 'new', 'medium', 0, 0, '2025-11-08 10:34:28', '2025-11-08 10:34:28');

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
CREATE TABLE IF NOT EXISTS `notes` (
  `note_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`note_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 ;

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`note_id`, `user_id`, `title`, `content`, `created_at`, `updated_at`) VALUES
(1, 1, 'Introduction to Python', 'Python is a high-level, interpreted programming language known for its simplicity and readability. It supports multiple programming paradigms including procedural, object-oriented, and functional programming. Python is widely used in web development, data science, artificial intelligence, and scientific computing. Key features include dynamic typing, automatic memory management, and a comprehensive standard library.', '2025-11-08 10:45:36', '2025-11-08 10:45:36'),
(2, 1, 'Photosynthesis Process', 'Photosynthesis is the process by which plants, algae, and some bacteria convert light energy into chemical energy stored in glucose. The process occurs in two main stages: the light-dependent reactions and the light-independent reactions (Calvin cycle). During the light reactions, chlorophyll absorbs photons and transfers electrons through the electron transport chain. The Calvin cycle uses ATP and NADPH to fix CO2 into glucose. This process is essential for life on Earth as it produces oxygen and forms the base of most food chains.', '2025-11-08 10:45:36', '2025-11-08 10:45:36'),
(3, 1, 'World War II Timeline', 'World War II lasted from 1939 to 1945 and was one of the most significant events in human history. Key events include: Germany invades Poland (September 1939), Battle of Britain (1940), Germany invades Soviet Union (June 1941), Japan attacks Pearl Harbor (December 1941), D-Day invasion of Normandy (June 1944), and Germany surrenders (May 1945). The war resulted in approximately 70-85 million deaths and fundamentally changed the global political landscape, leading to the formation of the United Nations and the beginning of the Cold War.', '2025-11-08 10:45:36', '2025-11-08 10:45:36'),
(4, 1, 'Calculus: Derivatives and Integrals', 'Calculus is a branch of mathematics focused on rates of change (derivatives) and accumulation (integrals). A derivative measures how a function changes as its input changes, representing the slope of the tangent line at any point. The derivative of f(x) is denoted as f(x) or df/dx. An integral is the reverse process of differentiation, used to find the area under a curve. The fundamental theorem of calculus states that differentiation and integration are inverse operations. Applications include optimization, motion analysis, and area/volume calculations.', '2025-11-08 10:45:36', '2025-11-08 10:45:36');

-- --------------------------------------------------------

--
-- Table structure for table `pomodoro_sessions`
--

DROP TABLE IF EXISTS `pomodoro_sessions`;
CREATE TABLE IF NOT EXISTS `pomodoro_sessions` (
  `session_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `duration_minutes` int NOT NULL,
  `session_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`session_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 ;

--
-- Dumping data for table `pomodoro_sessions`
--

INSERT INTO `pomodoro_sessions` (`session_id`, `user_id`, `duration_minutes`, `session_date`) VALUES
(1, 1, 25, '2025-11-08 09:30:00'),
(2, 1, 50, '2025-11-08 11:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `progress`
--

DROP TABLE IF EXISTS `progress`;
CREATE TABLE IF NOT EXISTS `progress` (
  `progress_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `total_notes` int DEFAULT '0',
  `total_flashcards` int DEFAULT '0',
  `total_pomodoro_minutes` int DEFAULT '0',
  `last_study_date` datetime DEFAULT NULL,
  PRIMARY KEY (`progress_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ;

--
-- Dumping data for table `progress`
--

INSERT INTO `progress` (`progress_id`, `user_id`, `total_notes`, `total_flashcards`, `total_pomodoro_minutes`, `last_study_date`) VALUES
(1, 1, 0, 0, 0, '2025-11-08 10:51:06');

-- --------------------------------------------------------

--
-- Table structure for table `study_sessions`
--

DROP TABLE IF EXISTS `study_sessions`;
CREATE TABLE IF NOT EXISTS `study_sessions` (
  `session_id` int NOT NULL AUTO_INCREMENT,
  `session_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `category` varchar(100) NOT NULL,
  `total_cards` int NOT NULL,
  `cards_learned` int DEFAULT '0',
  `cards_not_learned` int DEFAULT '0',
  `score` int DEFAULT '0',
  `time_spent` int DEFAULT '0',
  `status` enum('completed','incomplete','timeout') DEFAULT 'incomplete',
  PRIMARY KEY (`session_id`),
  KEY `idx_category` (`category`),
  KEY `idx_date` (`session_date`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 ;

--
-- Dumping data for table `study_sessions`
--

INSERT INTO `study_sessions` (`session_id`, `session_date`, `category`, `total_cards`, `cards_learned`, `cards_not_learned`, `score`, `time_spent`, `status`) VALUES
(1, '2025-11-08 10:35:21', 'Web Development', 10, 10, 0, 10, 11, 'completed'),
(2, '2025-11-09 16:32:44', 'Web Development', 10, 9, 1, 9, 15, 'completed');

-- --------------------------------------------------------

--
-- Table structure for table `summaries`
--

DROP TABLE IF EXISTS `summaries`;
CREATE TABLE IF NOT EXISTS `summaries` (
  `summary_id` int NOT NULL AUTO_INCREMENT,
  `note_id` int NOT NULL,
  `summary_text` longtext NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`summary_id`),
  KEY `idx_note_id` (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 ;

--
-- Dumping data for table `summaries`
--

INSERT INTO `summaries` (`summary_id`, `note_id`, `summary_text`, `created_at`) VALUES
(1, 2, '**Summary:**\n\n**Photosynthesis** is the biological process where light energy is converted into stored chemical energy (glucose) by organisms like plants, algae, and some bacteria.\n\nIt has two stages:\n1.  **Light-dependent reactions:** Occur in the presence of light. Chlorophyll captures light energy, which drives an electron transport chain and produces energy carriers (ATP, NADPH) and oxygen as a byproduct.\n2.  **Light-independent reactions (Calvin cycle):** Occur in the dark. They use the energy carriers (ATP, NADPH) from the light reactions and carbon dioxide', '2025-11-08 10:48:29'),
(2, 1, 'Okay, here is a concise summary of your study notes:\n\n# Python Summary\n\n*   **Basic Info:** High-level, interpreted language known for simplicity and readability.\n*   **Programming Styles:** Supports procedural, object-oriented, and functional programming.\n*   **Main Uses:** Widely used in web development, data science, AI, and scientific computing.\n*   **Key Features:**\n    *   Dynamic typing\n    *   Automatic memory management (garbage collection', '2025-11-08 10:54:48'),
(3, 3, 'Here is a concise summary of your study notes on World War II:\n\nWorld War II was the deadliest conflict in human history (1939-', '2025-11-08 10:55:13');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
CREATE TABLE IF NOT EXISTS `tasks` (
  `task_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `details` text,
  `is_completed` tinyint(1) DEFAULT '0',
  `due_date` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`task_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 ;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`task_id`, `user_id`, `title`, `description`, `details`, `is_completed`, `due_date`, `created_at`, `updated_at`) VALUES
(1, 1, 'Complete Java Practice', 'Solve 5 Java coding exercises focusing on loops and arrays.', 'Use HackerRank or LeetCode for practice.', 1, '2025-11-10 18:00:00', '2025-11-08 10:35:46', '2025-11-09 16:33:22'),
(2, 1, 'Finish Web Development Module', 'Study JavaScript ES6 concepts and DOM manipulation.', 'Watch a 1-hour tutorial and take notes.', 0, '2025-11-12 17:00:00', '2025-11-08 10:35:46', '2025-11-08 10:35:46'),
(3, 1, 'Review Database Concepts', 'Revise normalization, joins, and SQL queries.', 'Create sample tables and practice SELECT queries.', 0, '2025-11-14 20:00:00', '2025-11-08 10:35:46', '2025-11-08 10:35:46'),
(4, 1, 'AI Research Summary', 'Write a one-page summary on supervised vs unsupervised learning.', 'Summarize key points with examples.', 1, '2025-11-15 16:00:00', '2025-11-08 10:35:46', '2025-11-08 10:35:51'),
(5, 1, 'Plan Pomodoro Sessions', 'Create a weekly plan using Pomodoro technique for study time.', 'Set up 25-minute focus sessions for each topic.', 0, '2025-11-09 10:00:00', '2025-11-08 10:35:46', '2025-11-08 10:35:46');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ;
