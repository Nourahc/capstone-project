<?php
// CORS headers for Flutter Web
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

header('Content-Type: application/json');
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$note_id = $data['note_id'] ?? '';
$user_id = $data['user_id'] ?? '';

if (empty($note_id) || empty($user_id)) {
    echo json_encode(['success' => false, 'message' => 'Note ID and User ID are required']);
    exit;
}

// Verify note belongs to user
$verify_stmt = $conn->prepare("SELECT note_id FROM notes WHERE note_id = ? AND user_id = ?");
$verify_stmt->bind_param("ii", $note_id, $user_id);
$verify_stmt->execute();
$result = $verify_stmt->get_result();
if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Note not found or unauthorized']);
    $verify_stmt->close();
    exit;
}
$verify_stmt->close();

// Delete note
$stmt = $conn->prepare("DELETE FROM notes WHERE note_id = ?");
$stmt->bind_param("i", $note_id);

if ($stmt->execute()) {
    $progress_stmt = $conn->prepare("UPDATE progress SET total_notes = GREATEST(0, total_notes - 1) WHERE user_id = ?");
    $progress_stmt->bind_param("i", $user_id);
    $progress_stmt->execute();
    $progress_stmt->close();

    echo json_encode(['success' => true, 'message' => 'Note deleted successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to delete note']);
}

$stmt->close();
$conn->close();
?>
