<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $task_id = $data['task_id'] ?? '';
    $user_id = $data['user_id'] ?? '';
    
    if (empty($task_id) || empty($user_id)) {
        echo json_encode(['success' => false, 'message' => 'Task ID and User ID are required']);
        exit;
    }
    
    // Verify task belongs to user before deleting
    $verify_stmt = $conn->prepare("SELECT task_id FROM tasks WHERE task_id = ? AND user_id = ?");
    $verify_stmt->bind_param("ii", $task_id, $user_id);
    $verify_stmt->execute();
    $result = $verify_stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Task not found or unauthorized']);
        $verify_stmt->close();
        exit;
    }
    $verify_stmt->close();
    
    // Delete task
    $stmt = $conn->prepare("DELETE FROM tasks WHERE task_id = ?");
    $stmt->bind_param("i", $task_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Task deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete task']);
    }
    
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?>