<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

require_once 'config.php';

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Handle different actions
$action = $input['action'] ?? 'create';

if ($action === 'delete') {
    // Delete summary
    $summary_id = $input['summary_id'] ?? null;
    
    if (!$summary_id) {
        echo json_encode(['success' => false, 'message' => 'Summary ID is required']);
        exit;
    }
    
    $stmt = $conn->prepare("DELETE FROM summaries WHERE summary_id = ?");
    $stmt->bind_param("i", $summary_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Summary deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete summary']);
    }
    
    $stmt->close();
    $conn->close();
    exit;
}

// Create/Save summary (default action)
$note_id = $input['note_id'] ?? null;
$summary_text = $input['summary_text'] ?? null;

// Validate input
if (!$note_id || !$summary_text) {
    echo json_encode([
        'success' => false,
        'message' => 'Note ID and summary text are required'
    ]);
    exit;
}

// Validate that the note exists
$stmt = $conn->prepare("SELECT note_id FROM notes WHERE note_id = ?");
$stmt->bind_param("i", $note_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Note not found'
    ]);
    $stmt->close();
    $conn->close();
    exit;
}
$stmt->close();

// Insert summary into database
$stmt = $conn->prepare("INSERT INTO summaries (note_id, summary_text) VALUES (?, ?)");
$stmt->bind_param("is", $note_id, $summary_text);

if ($stmt->execute()) {
    $summary_id = $conn->insert_id;
    
    echo json_encode([
        'success' => true,
        'message' => 'Summary saved successfully',
        'summary_id' => $summary_id,
        'data' => [
            'note_id' => $note_id,
            'summary_text' => $summary_text
        ]
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Failed to save summary: ' . $conn->error
    ]);
}

$stmt->close();
$conn->close();
?>