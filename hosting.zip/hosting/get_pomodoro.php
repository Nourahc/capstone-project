<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $user_id = $_GET['user_id'] ?? '';
    
    if (empty($user_id)) {
        echo json_encode(['success' => false, 'message' => 'User ID is required']);
        exit;
    }
    
    $stmt = $conn->prepare("SELECT session_id, duration_minutes, session_date FROM pomodoro_sessions WHERE user_id = ? ORDER BY session_date DESC");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $sessions = [];
    $total_minutes = 0;
    
    while ($row = $result->fetch_assoc()) {
        $sessions[] = $row;
        $total_minutes += $row['duration_minutes'];
    }
    
    echo json_encode([
        'success' => true, 
        'sessions' => $sessions,
        'total_minutes' => $total_minutes,
        'total_sessions' => count($sessions)
    ]);
    
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?>