<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $user_id = intval($_GET['user_id'] ?? 0);
    
    if (empty($user_id)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'User ID is required']);
        exit;
    }
    
    try {
        // Total notes - FIXED: Using prepared statement
        $stmt = $conn->prepare("SELECT COUNT(*) as total_notes FROM notes WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $notes_result = $stmt->get_result();
        $notes_data = $notes_result->fetch_assoc();
        $total_notes = $notes_data['total_notes'] ?? 0;
        $stmt->close();
        
        // Total flashcards - FIXED: Removed invalid note_id JOIN
        // NOTE: Current schema doesn't link flashcards to users
        // Flashcards have 'category' field instead
        // If you need user-specific flashcards, add user_id column to flashcards table
        $stmt = $conn->prepare("SELECT COUNT(*) as total_flashcards FROM flashcards");
        $stmt->execute();
        $flashcards_result = $stmt->get_result();
        $flashcards_data = $flashcards_result->fetch_assoc();
        $total_flashcards = $flashcards_data['total_flashcards'] ?? 0;
        $stmt->close();
        
        // Total pomodoro minutes - FIXED: Using prepared statement
        $stmt = $conn->prepare("SELECT COALESCE(SUM(duration_minutes), 0) as total_pomodoro_minutes FROM pomodoro_sessions WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $pomodoro_result = $stmt->get_result();
        $pomodoro_data = $pomodoro_result->fetch_assoc();
        $total_pomodoro_minutes = $pomodoro_data['total_pomodoro_minutes'] ?? 0;
        $stmt->close();
        
        // Total tasks - FIXED: Using prepared statement
        $stmt = $conn->prepare("SELECT COUNT(*) as total_tasks FROM tasks WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $tasks_result = $stmt->get_result();
        $tasks_data = $tasks_result->fetch_assoc();
        $total_tasks = $tasks_data['total_tasks'] ?? 0;
        $stmt->close();
        
        // Pending tasks - FIXED: Using prepared statement
        $stmt = $conn->prepare("SELECT COUNT(*) as pending_tasks FROM tasks WHERE user_id = ? AND is_completed = 0");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $pending_result = $stmt->get_result();
        $pending_data = $pending_result->fetch_assoc();
        $pending_tasks = $pending_data['pending_tasks'] ?? 0;
        $stmt->close();
        
        // Last study date - FIXED: Using prepared statement
        $stmt = $conn->prepare("SELECT MAX(session_date) as last_study_date FROM pomodoro_sessions WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $date_result = $stmt->get_result();
        $date_data = $date_result->fetch_assoc();
        $last_study_date = $date_data['last_study_date'] ?? null;
        $stmt->close();
        
        $progress = [
            'total_notes' => intval($total_notes),
            'total_flashcards' => intval($total_flashcards),
            'total_pomodoro_minutes' => intval($total_pomodoro_minutes),
            'total_tasks' => intval($total_tasks),
            'pending_tasks' => intval($pending_tasks),
            'last_study_date' => $last_study_date
        ];
        
        http_response_code(200);
        echo json_encode(['success' => true, 'progress' => $progress]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Error fetching progress: ' . $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?>