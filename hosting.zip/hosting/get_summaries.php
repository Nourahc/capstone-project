<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once 'config.php';

// Get note_id from query parameters
$note_id = $_GET['note_id'] ?? null;

// Validate input
if (!$note_id) {
    echo json_encode([
        'success' => false,
        'message' => 'Note ID is required'
    ]);
    exit;
}

// Fetch all summaries for the given note
$stmt = $conn->prepare("
    SELECT 
        summary_id,
        note_id,
        summary_text,
        DATE_FORMAT(created_at, '%Y-%m-%d %H:%i:%s') as created_at
    FROM summaries 
    WHERE note_id = ? 
    ORDER BY created_at DESC
");

$stmt->bind_param("i", $note_id);
$stmt->execute();
$result = $stmt->get_result();

$summaries = [];
while ($row = $result->fetch_assoc()) {
    $summaries[] = $row;
}

if (count($summaries) > 0) {
    echo json_encode([
        'success' => true,
        'count' => count($summaries),
        'summaries' => $summaries
    ]);
} else {
    echo json_encode([
        'success' => true,
        'count' => 0,
        'summaries' => [],
        'message' => 'No summaries found for this note'
    ]);
}

$stmt->close();
$conn->close();
?>