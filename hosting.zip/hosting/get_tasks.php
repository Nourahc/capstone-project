<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $user_id = intval($_GET['user_id'] ?? 0);
    
    if (empty($user_id)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'User ID is required']);
        exit;
    }
    
    try {
        // Fixed query - removed note_id LEFT JOIN since it doesn't exist in tasks table
        $stmt = $conn->prepare("
            SELECT t.task_id, t.title, t.description, t.details, t.is_completed, t.due_date, t.created_at
            FROM tasks t
            WHERE t.user_id = ?
            ORDER BY t.is_completed ASC, t.created_at DESC
        ");
        
        if (!$stmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        
        $stmt->bind_param("i", $user_id);
        
        if (!$stmt->execute()) {
            throw new Exception("Execute failed: " . $stmt->error);
        }
        
        $result = $stmt->get_result();
        
        $tasks = [];
        $completed_count = 0;
        $pending_count = 0;
        
        while ($row = $result->fetch_assoc()) {
            $tasks[] = $row;
            if ($row['is_completed'] == 1) {
                $completed_count++;
            } else {
                $pending_count++;
            }
        }
        
        http_response_code(200);
        echo json_encode([
            'success' => true,
            'tasks' => $tasks,
            'completed_count' => $completed_count,
            'pending_count' => $pending_count
        ]);
        
        $stmt->close();
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Error fetching tasks: ' . $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?>