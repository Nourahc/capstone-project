====================
connection
config.dart 
config.php
====================


====================
page main dashboard ->progess page
main.dart 
get_progress.php
=====
ProgressActivity.dart
get_progress.php
====================

====================
page flashcard
FlashcardsActivity.dart
get_categories.php
get_flashcards.php
update_flashcard_status.php
save_session.php
====================

====================
page login
LoginActivity.dart
login.php
====================

 

====================
page notes- >notes details->generated ai summary 
NotesActivity.dart
get_notes.php
delete_note.php
=========== 
NoteDetailActivity.dart
update_note.php
add_note.php
===========
SummaryActivity.dart
generate_summary.php
get_summaries.php
====================

====================
page pomodoro
PomodoroActivity.dart
get_pomodoro.php
add_pomodoro.php
 
====================
page signup
RegisterActivity.dart
register.php

====================
 
====================
page task
TasksActivity.dart
get_tasks.php
update_task.php
delete_task.php
add_task.php
update_task.php
====================