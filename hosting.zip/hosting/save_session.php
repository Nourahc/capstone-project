<?php
require_once 'config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid request method']);
        exit;
    }
    
    $data = json_decode(file_get_contents("php://input"), true);
    
    $required_fields = ['category', 'total_cards', 'cards_learned', 'cards_not_learned', 'score', 'time_spent', 'status'];
    foreach ($required_fields as $field) {
        if (!isset($data[$field])) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => "Missing field: $field"]);
            exit;
        }
    }
    
    $category = $conn->real_escape_string($data['category']);
    $total_cards = (int)$data['total_cards'];
    $cards_learned = (int)$data['cards_learned'];
    $cards_not_learned = (int)$data['cards_not_learned'];
    $score = (int)$data['score'];
    $time_spent = (int)$data['time_spent'];
    $status = $conn->real_escape_string($data['status']);
    
    $query = "INSERT INTO study_sessions 
              (category, total_cards, cards_learned, cards_not_learned, score, time_spent, status) 
              VALUES 
              ('$category', $total_cards, $cards_learned, $cards_not_learned, $score, $time_spent, '$status')";
    
    if (!$conn->query($query)) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Insert failed: ' . $conn->error]);
        exit;
    }
    
    $session_id = $conn->insert_id;
    
    http_response_code(200);
    echo json_encode(['success' => true, 'message' => 'Session saved', 'data' => ['session_id' => $session_id]]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>