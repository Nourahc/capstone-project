<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Include database configuration
require_once 'config.php';

// Initialize response array
$response = array();

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['success'] = false;
    $response['message'] = 'Invalid request method. Use POST.';
    echo json_encode($response);
    exit();
}

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Validate required fields
if (!isset($data['note_id']) || empty($data['note_id'])) {
    $response['success'] = false;
    $response['message'] = 'Note ID is required';
    echo json_encode($response);
    exit();
}

if (!isset($data['user_id']) || empty($data['user_id'])) {
    $response['success'] = false;
    $response['message'] = 'User ID is required';
    echo json_encode($response);
    exit();
}

if (!isset($data['title']) || empty(trim($data['title']))) {
    $response['success'] = false;
    $response['message'] = 'Title is required';
    echo json_encode($response);
    exit();
}

if (!isset($data['content']) || empty(trim($data['content']))) {
    $response['success'] = false;
    $response['message'] = 'Content is required';
    echo json_encode($response);
    exit();
}

// Sanitize input
$note_id = intval($data['note_id']);
$user_id = intval($data['user_id']);
$title = trim($data['title']);
$content = trim($data['content']);

// Verify that the note belongs to the user
$check_query = "SELECT note_id FROM notes WHERE note_id = ? AND user_id = ?";
$check_stmt = $conn->prepare($check_query);
$check_stmt->bind_param("ii", $note_id, $user_id);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows === 0) {
    $response['success'] = false;
    $response['message'] = 'Note not found or you do not have permission to edit this note';
    echo json_encode($response);
    $check_stmt->close();
    exit();
}
$check_stmt->close();

// Prepare and execute update query
$update_query = "UPDATE notes SET title = ?, content = ?, updated_at = NOW() WHERE note_id = ? AND user_id = ?";
$update_stmt = $conn->prepare($update_query);

if (!$update_stmt) {
    $response['success'] = false;
    $response['message'] = 'Database error: ' . $conn->error;
    echo json_encode($response);
    exit();
}

$update_stmt->bind_param("ssii", $title, $content, $note_id, $user_id);

if ($update_stmt->execute()) {
    if ($update_stmt->affected_rows > 0) {
        $response['success'] = true;
        $response['message'] = 'Note updated successfully';
        $response['note_id'] = $note_id;
    } else {
        // No rows affected - content might be the same
        $response['success'] = true;
        $response['message'] = 'Note saved (no changes detected)';
        $response['note_id'] = $note_id;
    }
} else {
    $response['success'] = false;
    $response['message'] = 'Failed to update note: ' . $update_stmt->error;
}

$update_stmt->close();
$conn->close();

echo json_encode($response);
?>