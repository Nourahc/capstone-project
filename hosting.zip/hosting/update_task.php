<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $task_id = $data['task_id'] ?? '';
    $title = $data['title'] ?? null;
    $description = $data['description'] ?? null;
    $is_completed = $data['is_completed'] ?? null;
    $due_date = $data['due_date'] ?? null;
    
    if (empty($task_id)) {
        echo json_encode(['success' => false, 'message' => 'Task ID is required']);
        exit;
    }
    
    // Build dynamic update query based on provided fields
    $updates = [];
    $types = '';
    $values = [];
    
    if ($title !== null) {
        $updates[] = "title = ?";
        $types .= 's';
        $values[] = $title;
    }
    
    if ($description !== null) {
        $updates[] = "description = ?";
        $types .= 's';
        $values[] = $description;
    }
    
    if ($is_completed !== null) {
        $updates[] = "is_completed = ?";
        $types .= 'i';
        $values[] = $is_completed;
    }
    
    if ($due_date !== null) {
        $updates[] = "due_date = ?";
        $types .= 's';
        $values[] = $due_date;
    }
    
    if (empty($updates)) {
        echo json_encode(['success' => false, 'message' => 'No fields to update']);
        exit;
    }
    
    $values[] = $task_id;
    $types .= 'i';
    
    $sql = "UPDATE tasks SET " . implode(", ", $updates) . " WHERE task_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$values);
    
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode(['success' => true, 'message' => 'Task updated successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Task not found or no changes made']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update task']);
    }
    
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?>